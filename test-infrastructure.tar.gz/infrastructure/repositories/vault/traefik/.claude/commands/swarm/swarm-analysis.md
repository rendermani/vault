# swarm-analysis

Command documentation for swarm-analysis in category swarm.

Usage:
```bash
npx claude-flow swarm swarm-analysis [options]
```
