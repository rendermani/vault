# hive-mind-wizard

Command documentation for hive-mind-wizard in category hive-mind.

Usage:
```bash
npx claude-flow hive-mind hive-mind-wizard [options]
```
