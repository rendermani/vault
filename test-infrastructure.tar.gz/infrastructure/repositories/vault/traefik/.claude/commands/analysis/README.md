# Analysis Commands

Commands for analysis operations in Claude Flow.

## Available Commands

- [bottleneck-detect](./bottleneck-detect.md)
- [token-usage](./token-usage.md)
- [performance-report](./performance-report.md)
