# Automation Commands

Commands for automation operations in Claude Flow.

## Available Commands

- [auto-agent](./auto-agent.md)
- [smart-spawn](./smart-spawn.md)
- [workflow-select](./workflow-select.md)
