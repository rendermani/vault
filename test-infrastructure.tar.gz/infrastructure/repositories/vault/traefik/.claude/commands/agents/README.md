# Agents Commands

Commands for agents operations in Claude Flow.

## Available Commands

- [agent-types](./agent-types.md)
- [agent-capabilities](./agent-capabilities.md)
- [agent-coordination](./agent-coordination.md)
- [agent-spawning](./agent-spawning.md)
