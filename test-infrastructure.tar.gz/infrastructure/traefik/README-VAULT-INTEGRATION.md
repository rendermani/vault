# Traefik-Vault Integration Setup

This document provides comprehensive instructions for setting up Traefik with HashiCorp Vault integration for secure secret management and PKI certificate handling.

## 🏗️ Architecture Overview

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   GitHub        │    │   HashiCorp     │    │   Traefik       │
│   Actions       │───▶│   Vault         │◀───│   Service       │
│                 │    │                 │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                              │                         │
                       ┌──────┴──────┐         ┌─────┴─────┐
                       │             │         │           │
                 ┌─────▼─────┐ ┌─────▼─────┐  │    PKI    │
                 │  Secrets  │ │    PKI    │  │   Certs   │
                 │  Engine   │ │  Engine   │  │           │
                 └───────────┘ └───────────┘  └───────────┘
```

## 📋 Prerequisites

1. **Vault Server**: Running and accessible at `https://vault.cloudya.net`
2. **Vault Token**: With admin privileges for initial setup
3. **Domain**: DNS configured for `*.cloudya.net`
4. **Docker**: For containerized deployment
5. **Cloudflare Account**: For DNS challenge (optional)

## 🚀 Quick Start

### 1. Clone and Setup

```bash
# Repository already cloned to infrastructure/traefik
cd infrastructure/traefik

# Copy environment template
cp .env.example .env

# Edit configuration
nano .env
```

### 2. Initialize Vault Integration

```bash
# Set Vault credentials
export VAULT_ADDR=https://vault.cloudya.net
export VAULT_TOKEN=your-vault-token

# Setup Vault policies and roles
./scripts/setup-vault-policies.sh

# Setup PKI certificates
./scripts/setup-pki-certificates.sh

# Run existing Vault integration setup
./scripts/setup-vault-integration.sh
```

### 3. Deploy Traefik

```bash
# Using Docker Compose with Vault integration
docker-compose -f docker-compose.vault.yml up -d

# Or using existing deployment scripts
./scripts/deploy-with-vault.sh
```

## 🔐 Vault Configuration

### Secret Paths

| Purpose | Vault Path | Fields |
|---------|------------|--------|
| Dashboard Auth | `kv/data/traefik/dashboard` | `username`, `password`, `auth` |
| Nomad Integration | `kv/data/traefik/nomad` | `token`, `addr` |
| Cloudflare DNS | `kv/data/traefik/cloudflare` | `email`, `api_key` |
| Service Token | `kv/data/traefik/vault` | `token` |
| PKI Certificates | `kv/data/traefik/certificates/{domain}` | `certificate`, `private_key`, `ca_certificate` |

### Policies Created

1. **traefik-service**: Runtime access to secrets
2. **traefik-admin**: Administrative access for management
3. **traefik-pki**: Certificate generation and management

### PKI Setup

- **Root CA**: `pki/` (87600h TTL)
- **Intermediate CA**: `pki_int/` (43800h TTL)
- **Server Role**: `traefik-server` (720h TTL)
- **Domains**: `*.cloudya.net`

## 🐳 Docker Compose Deployment

The `docker-compose.vault.yml` includes:

1. **Traefik Service**: Main reverse proxy with Vault integration
2. **Vault-Init**: Initializes secrets from Vault
3. **Vault-Agent**: Handles token renewal and secret templating

### Key Features

- **Secret Management**: All secrets fetched from Vault
- **Certificate Automation**: PKI certificates with auto-renewal
- **Token Renewal**: Vault Agent handles token lifecycle
- **Health Checks**: Comprehensive monitoring

## 📜 Generated Scripts

### setup-vault-policies.sh
- Creates Vault policies for Traefik
- Generates service tokens
- Configures PKI engine and roles

### setup-pki-certificates.sh
- Sets up PKI root and intermediate CAs
- Generates certificates for all services
- Configures automatic renewal

### init-vault-secrets.sh
- Fetches secrets from Vault at startup
- Creates fallback secrets if Vault unavailable
- Prepares secret files for Traefik

## 🔧 Configuration Files

### traefik.vault.yml
Enhanced Traefik configuration with:
- Vault certificate resolver
- Enhanced TLS options
- Vault-based dynamic configuration
- PKI certificate management

### Vault Agent Templates
- `dashboard-auth.tpl`: Dashboard authentication
- `cloudflare-email.tpl`: Cloudflare email
- `cloudflare-key.tpl`: Cloudflare API key
- `traefik-env.tpl`: Environment variables

## 🔍 Monitoring and Logging

- **Logs**: JSON format in `/var/log/traefik/`
- **Metrics**: Prometheus endpoint at `:8082/metrics`
- **Health**: Ping endpoint for monitoring
- **Dashboard**: Secure access via Vault credentials

## 🔄 Certificate Management

### Automatic Renewal
- Certificates auto-renew 7 days before expiry
- Vault Agent handles template updates
- Traefik reloads configuration automatically

### Manual Certificate Operations
```bash
# Check certificate status
vault read pki_int/cert/ca

# Generate new certificate
vault write pki_int/issue/traefik-server \
    common_name="example.cloudya.net" \
    ttl="720h"

# List certificates
vault list pki_int/certs
```

## 🛠️ Troubleshooting

### Check Vault Connectivity
```bash
vault status
vault auth -method=token token=your-token
```

### Verify Secrets
```bash
vault kv get kv/data/traefik/dashboard
vault kv list kv/data/traefik/
```

### Check Traefik Logs
```bash
docker logs traefik
tail -f data/logs/traefik.log
```

### Test Certificate Generation
```bash
vault write pki_int/issue/traefik-server \
    common_name="test.cloudya.net" \
    ttl="1h"
```

## 🚨 Security Considerations

1. **Token Security**: Store Vault tokens securely
2. **Network Security**: Use TLS for all communications
3. **Access Control**: Implement least-privilege policies
4. **Monitoring**: Enable audit logging in Vault
5. **Rotation**: Regular token and certificate rotation

## 📚 Next Steps

1. **Monitoring**: Setup Grafana dashboards for certificate expiry
2. **Automation**: Add certificate renewal to CI/CD pipeline
3. **Backup**: Implement Vault backup strategy
4. **Scaling**: Consider Vault clustering for HA
5. **Integration**: Connect with other services (Nomad, Consul)

## 🆘 Support

- **Vault Documentation**: https://www.vaultproject.io/docs
- **Traefik Documentation**: https://doc.traefik.io/traefik/
- **Repository Issues**: Create issues for bugs or questions

## 📝 Files Created

### Configuration Files
- `/infrastructure/traefik/docker-compose.vault.yml`
- `/infrastructure/traefik/config/traefik.vault.yml`
- `/infrastructure/traefik/config/vault-agent.hcl`
- `/infrastructure/traefik/.env.example`

### Template Files
- `/infrastructure/traefik/config/templates/dashboard-auth.tpl`
- `/infrastructure/traefik/config/templates/cloudflare-email.tpl`
- `/infrastructure/traefik/config/templates/cloudflare-key.tpl`
- `/infrastructure/traefik/config/templates/traefik-env.tpl`

### Scripts
- `/infrastructure/traefik/scripts/setup-vault-policies.sh`
- `/infrastructure/traefik/scripts/setup-pki-certificates.sh`
- `/infrastructure/traefik/scripts/init-vault-secrets.sh`

Ready for production deployment with enterprise-grade security! 🚀