#!/bin/bash
set -e

# Setup PKI Certificates for Traefik with Vault
# This script configures Vault PKI and generates certificates for Traefik

VAULT_ADDR="${VAULT_ADDR:-https://vault.cloudya.net}"
VAULT_TOKEN="${VAULT_TOKEN}"
DOMAIN="${DOMAIN:-cloudya.net}"

echo "🔐 Setting up PKI certificates for Traefik..."

# Function to check Vault connectivity
check_vault() {
    echo "Checking Vault connectivity..."
    if vault status >/dev/null 2>&1; then
        echo "✅ Vault is accessible at $VAULT_ADDR"
        return 0
    else
        echo "❌ Cannot connect to Vault at $VAULT_ADDR"
        return 1
    fi
}

# Function to setup PKI root CA
setup_root_ca() {
    echo "Setting up root CA..."
    
    # Enable PKI engine if not already enabled
    if ! vault secrets list | grep -q "pki/"; then
        echo "Enabling PKI secrets engine..."
        vault secrets enable pki
        vault secrets tune -max-lease-ttl=87600h pki
    else
        echo "PKI engine already enabled"
    fi
    
    # Check if root CA exists
    if vault read pki/cert/ca >/dev/null 2>&1; then
        echo "✅ Root CA already exists"
    else
        echo "Generating root CA..."
        vault write -field=certificate pki/root/generate/internal \
            common_name="Cloudya Internal Root CA" \
            ttl=87600h > /tmp/ca_cert.crt
        
        # Configure CA and CRL URLs
        vault write pki/config/urls \
            issuing_certificates="$VAULT_ADDR/v1/pki/ca" \
            crl_distribution_points="$VAULT_ADDR/v1/pki/crl"
        
        echo "✅ Root CA generated and configured"
    fi
}

# Function to setup intermediate CA
setup_intermediate_ca() {
    echo "Setting up intermediate CA for Traefik..."
    
    # Enable intermediate PKI engine
    if ! vault secrets list | grep -q "pki_int/"; then
        echo "Enabling intermediate PKI engine..."
        vault secrets enable -path=pki_int pki
        vault secrets tune -max-lease-ttl=43800h pki_int
    else
        echo "Intermediate PKI engine already enabled"
    fi
    
    # Check if intermediate CA exists
    if vault read pki_int/cert/ca >/dev/null 2>&1; then
        echo "✅ Intermediate CA already exists"
    else
        echo "Generating intermediate CA..."
        
        # Generate intermediate CSR
        vault write -format=json pki_int/intermediate/generate/internal \
            common_name="Cloudya Intermediate CA for Traefik" \
            | jq -r '.data.csr' > /tmp/pki_intermediate.csr
        
        # Sign intermediate CSR with root CA
        vault write -format=json pki/root/sign-intermediate \
            csr=@/tmp/pki_intermediate.csr \
            format=pem_bundle ttl="43800h" \
            | jq -r '.data.certificate' > /tmp/intermediate.cert.pem
        
        # Import signed certificate
        vault write pki_int/intermediate/set-signed \
            certificate=@/tmp/intermediate.cert.pem
        
        # Configure intermediate CA URLs
        vault write pki_int/config/urls \
            issuing_certificates="$VAULT_ADDR/v1/pki_int/ca" \
            crl_distribution_points="$VAULT_ADDR/v1/pki_int/crl"
        
        echo "✅ Intermediate CA generated and configured"
    fi
}

# Function to create certificate role for Traefik
create_traefik_role() {
    echo "Creating certificate role for Traefik..."
    
    vault write pki_int/roles/traefik-server \
        allowed_domains="$DOMAIN" \
        allow_subdomains=true \
        allow_wildcard_certificates=true \
        max_ttl="720h" \
        key_bits=2048 \
        key_type=rsa
    
    vault write pki_int/roles/traefik-client \
        allowed_domains="$DOMAIN" \
        allow_subdomains=true \
        max_ttl="720h" \
        key_bits=2048 \
        key_type=rsa
    
    echo "✅ Certificate roles created for Traefik"
}

# Function to generate server certificates
generate_server_certificates() {
    echo "Generating server certificates for Traefik..."
    
    local domains=(
        "traefik.$DOMAIN"
        "vault.$DOMAIN" 
        "nomad.$DOMAIN"
        "metrics.$DOMAIN"
        "grafana.$DOMAIN"
        "logs.$DOMAIN"
    )
    
    for domain in "${domains[@]}"; do
        echo "Generating certificate for $domain..."
        
        # Generate certificate
        vault write -format=json pki_int/issue/traefik-server \
            common_name="$domain" \
            ttl="720h" > "/tmp/${domain}.json"
        
        # Extract certificate components
        jq -r '.data.certificate' "/tmp/${domain}.json" > "/tmp/${domain}.crt"
        jq -r '.data.private_key' "/tmp/${domain}.json" > "/tmp/${domain}.key"
        jq -r '.data.issuing_ca' "/tmp/${domain}.json" > "/tmp/${domain}-ca.crt"
        
        # Store in Vault KV store for Traefik access
        vault kv put "kv/data/traefik/certificates/$domain" \
            certificate="$(cat /tmp/${domain}.crt)" \
            private_key="$(cat /tmp/${domain}.key)" \
            ca_certificate="$(cat /tmp/${domain}-ca.crt)" \
            created_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
            expires_at="$(date -u -d '+30 days' +%Y-%m-%dT%H:%M:%SZ)"
        
        echo "✅ Certificate generated and stored for $domain"
    done
}

# Function to setup certificate renewal
setup_certificate_renewal() {
    echo "Setting up certificate renewal automation..."
    
    # Create renewal script
    cat > /tmp/renew-traefik-certs.sh <<'EOF'
#!/bin/bash
set -e

VAULT_ADDR="${VAULT_ADDR:-https://vault.cloudya.net}"
VAULT_TOKEN="${VAULT_TOKEN}"
DOMAIN="${DOMAIN:-cloudya.net}"

echo "🔄 Renewing Traefik certificates..."

domains=(
    "traefik.$DOMAIN"
    "vault.$DOMAIN" 
    "nomad.$DOMAIN"
    "metrics.$DOMAIN"
    "grafana.$DOMAIN"
    "logs.$DOMAIN"
)

for domain in "${domains[@]}"; do
    echo "Renewing certificate for $domain..."
    
    # Check if certificate expires in next 7 days
    expires_at=$(vault kv get -field=expires_at "kv/data/traefik/certificates/$domain" 2>/dev/null || echo "")
    
    if [ ! -z "$expires_at" ]; then
        expires_epoch=$(date -d "$expires_at" +%s)
        renewal_epoch=$(date -d '+7 days' +%s)
        
        if [ $expires_epoch -lt $renewal_epoch ]; then
            echo "Certificate for $domain expires soon, renewing..."
            
            # Generate new certificate
            vault write -format=json pki_int/issue/traefik-server \
                common_name="$domain" \
                ttl="720h" > "/tmp/${domain}.json"
            
            # Update in Vault
            vault kv put "kv/data/traefik/certificates/$domain" \
                certificate="$(jq -r '.data.certificate' /tmp/${domain}.json)" \
                private_key="$(jq -r '.data.private_key' /tmp/${domain}.json)" \
                ca_certificate="$(jq -r '.data.issuing_ca' /tmp/${domain}.json)" \
                created_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
                expires_at="$(date -u -d '+30 days' +%Y-%m-%dT%H:%M:%SZ)"
            
            echo "✅ Certificate renewed for $domain"
        else
            echo "Certificate for $domain is still valid"
        fi
    else
        echo "⚠️ No certificate found for $domain"
    fi
done

echo "✅ Certificate renewal complete"
EOF
    
    chmod +x /tmp/renew-traefik-certs.sh
    
    # Store renewal script in Vault for cron job
    vault kv put kv/data/traefik/scripts \
        renewal_script="$(cat /tmp/renew-traefik-certs.sh)" \
        created_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    
    echo "✅ Certificate renewal script created and stored in Vault"
}

# Main setup process
main() {
    # Check prerequisites
    check_vault
    
    echo ""
    echo "🏗️ PKI Certificate Setup for Traefik"
    echo "===================================="
    echo "Domain: $DOMAIN"
    echo "Vault: $VAULT_ADDR"
    echo ""
    
    # Setup PKI infrastructure
    setup_root_ca
    setup_intermediate_ca
    create_traefik_role
    
    # Generate certificates
    generate_server_certificates
    
    # Setup renewal automation
    setup_certificate_renewal
    
    # Clean up temporary files
    rm -f /tmp/*.csr /tmp/*.crt /tmp/*.key /tmp/*.pem /tmp/*.json
    
    # Summary
    echo ""
    echo "========================================="
    echo "✅ PKI Certificate Setup Complete!"
    echo "========================================="
    echo ""
    echo "PKI Configuration:"
    echo "  • Root CA: pki/"
    echo "  • Intermediate CA: pki_int/"
    echo "  • Server Role: traefik-server"
    echo "  • Client Role: traefik-client"
    echo ""
    echo "Certificates generated for:"
    echo "  • traefik.$DOMAIN"
    echo "  • vault.$DOMAIN"
    echo "  • nomad.$DOMAIN"
    echo "  • metrics.$DOMAIN"
    echo "  • grafana.$DOMAIN"
    echo "  • logs.$DOMAIN"
    echo ""
    echo "Certificate storage: kv/data/traefik/certificates/"
    echo "Renewal script: kv/data/traefik/scripts"
    echo ""
    echo "Next steps:"
    echo "1. Setup cron job for certificate renewal"
    echo "2. Configure Traefik to use Vault certificates"
    echo "3. Test certificate validation"
}

# Run main function
main "$@"