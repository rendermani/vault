#!/bin/bash
set -e

# Setup Vault Policies for Traefik Integration
# This script creates the necessary Vault policies for Traefik service access

VAULT_ADDR="${VAULT_ADDR:-https://vault.cloudya.net}"
VAULT_TOKEN="${VAULT_TOKEN}"

echo "🔐 Setting up Vault policies for Traefik..."

# Function to check Vault connectivity
check_vault() {
    echo "Checking Vault connectivity..."
    if vault status >/dev/null 2>&1; then
        echo "✅ Vault is accessible at $VAULT_ADDR"
        return 0
    else
        echo "❌ Cannot connect to Vault at $VAULT_ADDR"
        return 1
    fi
}

# Function to create Vault policy
create_policy() {
    local policy_name=$1
    local policy_file=$2
    
    echo "Creating policy: $policy_name"
    
    if vault policy write "$policy_name" "$policy_file"; then
        echo "✅ Policy $policy_name created successfully"
        return 0
    else
        echo "❌ Failed to create policy $policy_name"
        return 1
    fi
}

# Main setup process
main() {
    # Check prerequisites
    check_vault
    
    # Create temporary policy files
    TEMP_DIR=$(mktemp -d)
    
    # 1. Traefik Service Policy
    echo "1️⃣ Creating Traefik Service Policy"
    echo "================================="
    
    cat > "$TEMP_DIR/traefik-service-policy.hcl" <<EOF
# Traefik Service Policy
# Allows Traefik to access its configuration secrets

# Dashboard credentials
path "kv/data/traefik/dashboard" {
  capabilities = ["read"]
}

path "kv/metadata/traefik/dashboard" {
  capabilities = ["read", "list"]
}

# SSL/TLS certificates
path "kv/data/traefik/certificates/*" {
  capabilities = ["read", "list"]
}

path "kv/metadata/traefik/certificates/*" {
  capabilities = ["read", "list"]
}

# Cloudflare API credentials for DNS challenge
path "kv/data/traefik/cloudflare" {
  capabilities = ["read"]
}

path "kv/metadata/traefik/cloudflare" {
  capabilities = ["read"]
}

# Nomad integration
path "kv/data/traefik/nomad" {
  capabilities = ["read"]
}

path "kv/metadata/traefik/nomad" {
  capabilities = ["read"]
}

# Allow token operations for renewal
path "auth/token/lookup-self" {
  capabilities = ["read"]
}

path "auth/token/renew-self" {
  capabilities = ["update"]
}

# Health check access
path "sys/health" {
  capabilities = ["read"]
}
EOF
    
    create_policy "traefik-service" "$TEMP_DIR/traefik-service-policy.hcl"
    
    # 2. Traefik Admin Policy
    echo ""
    echo "2️⃣ Creating Traefik Admin Policy"
    echo "================================"
    
    cat > "$TEMP_DIR/traefik-admin-policy.hcl" <<EOF
# Traefik Admin Policy
# Allows administrators to manage Traefik secrets

# Full access to Traefik secrets
path "kv/data/traefik/*" {
  capabilities = ["create", "read", "update", "delete", "list"]
}

path "kv/metadata/traefik/*" {
  capabilities = ["create", "read", "update", "delete", "list"]
}

# Certificate management
path "pki/cert/ca" {
  capabilities = ["read"]
}

path "pki/issue/traefik" {
  capabilities = ["create", "read", "update"]
}

# Policy management
path "sys/policies/acl/traefik-*" {
  capabilities = ["read", "list"]
}

# Token creation for service accounts
path "auth/token/create" {
  capabilities = ["create", "update"]
}
EOF
    
    create_policy "traefik-admin" "$TEMP_DIR/traefik-admin-policy.hcl"
    
    # 3. Traefik PKI Policy (for certificate management)
    echo ""
    echo "3️⃣ Creating Traefik PKI Policy"
    echo "=============================="
    
    cat > "$TEMP_DIR/traefik-pki-policy.hcl" <<EOF
# Traefik PKI Policy
# Allows Traefik to manage PKI certificates

# PKI certificate issuance
path "pki/issue/traefik-server" {
  capabilities = ["create", "read", "update"]
}

path "pki/issue/traefik-client" {
  capabilities = ["create", "read", "update"]
}

# Read CA certificate
path "pki/cert/ca" {
  capabilities = ["read"]
}

# Certificate revocation
path "pki/revoke" {
  capabilities = ["update"]
}

# List issued certificates
path "pki/certs" {
  capabilities = ["list"]
}
EOF
    
    create_policy "traefik-pki" "$TEMP_DIR/traefik-pki-policy.hcl"
    
    # 4. Create service token for Traefik
    echo ""
    echo "4️⃣ Creating Service Token for Traefik"
    echo "===================================="
    
    TRAEFIK_TOKEN=$(vault token create \
        -policy=traefik-service \
        -policy=traefik-pki \
        -period=768h \
        -renewable=true \
        -display-name="traefik-service" \
        -format=json | jq -r '.auth.client_token')
    
    if [ ! -z "$TRAEFIK_TOKEN" ]; then
        echo "✅ Service token created for Traefik"
        
        # Store token in Vault for other services to use
        vault kv put kv/data/traefik/vault \
            token="$TRAEFIK_TOKEN" \
            created_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
            policies="traefik-service,traefik-pki"
        
        echo "Token stored in Vault at: kv/data/traefik/vault"
        echo ""
        echo "🔑 Traefik Service Token: $TRAEFIK_TOKEN"
        echo ""
        echo "⚠️ Store this token securely and add it to your deployment secrets!"
        
    else
        echo "❌ Failed to create service token"
        exit 1
    fi
    
    # 5. Setup PKI engine if not exists
    echo ""
    echo "5️⃣ Setting up PKI Engine"
    echo "========================"
    
    # Check if PKI is already enabled
    if vault secrets list | grep -q "pki/"; then
        echo "✅ PKI engine already enabled"
    else
        echo "Enabling PKI secrets engine..."
        vault secrets enable pki
        
        # Configure max lease TTL
        vault secrets tune -max-lease-ttl=8760h pki
        
        echo "✅ PKI engine enabled"
    fi
    
    # Create PKI role for Traefik
    vault write pki/roles/traefik-server \
        allowed_domains="cloudya.net,*.cloudya.net" \
        allow_subdomains=true \
        max_ttl=8760h \
        key_bits=2048 \
        key_type=rsa
    
    echo "✅ PKI role created for Traefik"
    
    # Clean up temporary files
    rm -rf "$TEMP_DIR"
    
    # Summary
    echo ""
    echo "========================================="
    echo "✅ Vault Policies Setup Complete!"
    echo "========================================="
    echo ""
    echo "Created policies:"
    echo "  • traefik-service: Runtime access to secrets"
    echo "  • traefik-admin: Administrative access"
    echo "  • traefik-pki: Certificate management"
    echo ""
    echo "PKI Configuration:"
    echo "  • PKI engine enabled at pki/"
    echo "  • Server role: traefik-server"
    echo "  • Allowed domains: cloudya.net, *.cloudya.net"
    echo ""
    echo "Service Token: $TRAEFIK_TOKEN"
    echo ""
    echo "Next steps:"
    echo "1. Add VAULT_TOKEN to your environment: export VAULT_TOKEN=$TRAEFIK_TOKEN"
    echo "2. Store token in GitHub secrets or deployment system"
    echo "3. Test Traefik deployment with Vault integration"
}

# Run main function
main "$@"