#!/bin/bash
set -e

# Initialize Vault secrets for Traefik
# This script fetches secrets from Vault and prepares them for Traefik

VAULT_ADDR="${VAULT_ADDR:-https://vault.cloudya.net}"
VAULT_TOKEN="${VAULT_TOKEN}"
SECRETS_DIR="/secrets"

echo "🔐 Initializing Vault secrets for Traefik..."

# Function to check if Vault is accessible
check_vault() {
    echo "Checking Vault connectivity..."
    if vault status >/dev/null 2>&1; then
        echo "✅ Vault is accessible at $VAULT_ADDR"
        return 0
    else
        echo "❌ Cannot connect to Vault at $VAULT_ADDR"
        return 1
    fi
}

# Function to fetch secret from Vault
fetch_secret() {
    local vault_path=$1
    local field=$2
    local output_file=$3
    
    echo "Fetching $field from $vault_path..."
    
    if vault kv get -field="$field" "$vault_path" > "$output_file" 2>/dev/null; then
        echo "✅ Successfully fetched $field"
        chmod 640 "$output_file"
        return 0
    else
        echo "❌ Failed to fetch $field from $vault_path"
        return 1
    fi
}

# Function to create default secrets if Vault is not available
create_default_secrets() {
    echo "🔧 Creating default secrets (Vault unavailable)..."
    
    # Create default Vault token file
    echo "${VAULT_TOKEN:-demo-token}" > "$SECRETS_DIR/vault_token"
    chmod 640 "$SECRETS_DIR/vault_token"
    
    # Create default dashboard auth
    echo "admin:\$2y\$10\$default.hash.for.testing" > "$SECRETS_DIR/dashboard_auth"
    chmod 640 "$SECRETS_DIR/dashboard_auth"
    
    # Create placeholder Cloudflare credentials
    echo "admin@cloudya.net" > "$SECRETS_DIR/cf_api_email"
    echo "placeholder-api-key" > "$SECRETS_DIR/cf_api_key"
    chmod 640 "$SECRETS_DIR/cf_api_email"
    chmod 640 "$SECRETS_DIR/cf_api_key"
    
    echo "⚠️ Using default secrets. Update these for production!"
}

# Main initialization
main() {
    # Ensure secrets directory exists
    mkdir -p "$SECRETS_DIR"
    
    # Check Vault connectivity
    if check_vault; then
        echo "🔄 Fetching secrets from Vault..."
        
        # Fetch dashboard authentication
        if fetch_secret "kv/data/traefik/dashboard" "auth" "$SECRETS_DIR/dashboard_auth"; then
            echo "✅ Dashboard authentication configured"
        else
            echo "⚠️ Using fallback dashboard auth"
            echo "admin:\$2y\$10\$fallback.hash" > "$SECRETS_DIR/dashboard_auth"
        fi
        
        # Fetch Cloudflare credentials
        if fetch_secret "kv/data/traefik/cloudflare" "email" "$SECRETS_DIR/cf_api_email" && \
           fetch_secret "kv/data/traefik/cloudflare" "api_key" "$SECRETS_DIR/cf_api_key"; then
            echo "✅ Cloudflare credentials configured"
        else
            echo "⚠️ Cloudflare credentials not found, using placeholders"
            echo "admin@cloudya.net" > "$SECRETS_DIR/cf_api_email"
            echo "placeholder-key" > "$SECRETS_DIR/cf_api_key"
        fi
        
        # Store Vault token for agent
        echo "$VAULT_TOKEN" > "$SECRETS_DIR/vault_token"
        chmod 640 "$SECRETS_DIR/vault_token"
        
        echo "✅ Vault secrets initialization complete!"
        
    else
        echo "⚠️ Vault is not available, using default secrets"
        create_default_secrets
    fi
    
    # List created files (without content)
    echo ""
    echo "📋 Secret files created:"
    ls -la "$SECRETS_DIR/" | grep -v '^total'
    
    echo ""
    echo "🚀 Ready to start Traefik with Vault integration!"
}

# Run main function
main "$@"