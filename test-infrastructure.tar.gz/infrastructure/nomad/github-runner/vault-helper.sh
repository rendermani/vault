#!/bin/bash

# Vault Helper Script for GitHub Actions Runner
# Provides easy access to Vault secrets from within GitHub Actions workflows

set -e

# Function to log messages
log() {
    echo "[VAULT-HELPER] $1" >&2
}

# Function to authenticate with Vault if not already authenticated
ensure_vault_auth() {
    # Handle test mode
    if [[ "${TEST_MODE}" == "true" ]]; then
        log "🧪 Test mode: Using mock Vault authentication"
        export VAULT_TOKEN="test-root-token"
        mkdir -p /home/runner/.vault
        echo "${VAULT_TOKEN}" > /home/runner/.vault/token
        return 0
    fi
    
    if [[ ! -f "/home/runner/.vault/token" ]] || ! vault auth -method=token >/dev/null 2>&1; then
        log "🔐 Authenticating with Vault..."
        
        if [[ -n "${VAULT_ROLE_ID}" && -n "${VAULT_SECRET_ID}" ]]; then
            export VAULT_TOKEN=$(vault write -field=token auth/approle/login \
                role_id="${VAULT_ROLE_ID}" \
                secret_id="${VAULT_SECRET_ID}")
            
            if [[ $? -eq 0 && -n "${VAULT_TOKEN}" ]]; then
                echo "${VAULT_TOKEN}" > /home/runner/.vault/token
                log "✅ Successfully authenticated with Vault"
            else
                log "❌ Failed to authenticate with Vault"
                exit 1
            fi
        elif [[ -n "${VAULT_TOKEN}" ]]; then
            echo "${VAULT_TOKEN}" > /home/runner/.vault/token
        else
            log "❌ No Vault authentication credentials available"
            exit 1
        fi
    fi
    
    export VAULT_TOKEN=$(cat /home/runner/.vault/token)
}

# Function to get secret from Vault
get_secret() {
    local path="$1"
    local key="$2"
    local format="${3:-value}"  # value, json, or env
    
    ensure_vault_auth
    
    # Test mode mock data
    if [[ "${TEST_MODE}" == "true" ]]; then
        case "$path" in
            "test/runner-demo")
                case "$key" in
                    "fake_password") echo "super-secret-test-password-123" ;;
                    "demo_api_key") echo "demo-api-key-xyz789" ;;
                    "test_message") echo "Hello from Vault in GitHub Actions!" ;;
                    *) echo "test-value-for-${key}" ;;
                esac
                return 0
                ;;
            "cloudya/test")
                case "$key" in
                    "environment") echo "testing" ;;
                    "fake_db_password") echo "fake-db-password-456" ;;
                    "test_domain") echo "test.cloudya.net" ;;
                    "debug_enabled") echo "true" ;;
                    *) echo "cloudya-test-value-for-${key}" ;;
                esac
                return 0
                ;;
            *)
                echo "mock-value-for-${path}/${key}"
                return 0
                ;;
        esac
    fi
    
    case "$format" in
        "json")
            vault kv get -format=json "secret/${path}" | jq -r '.data.data'
            ;;
        "env")
            vault kv get -format=json "secret/${path}" | jq -r '.data.data | to_entries[] | "\(.key)=\(.value)"'
            ;;
        "value"|*)
            if [[ -n "$key" ]]; then
                vault kv get -field="${key}" "secret/${path}"
            else
                vault kv get -format=json "secret/${path}" | jq -r '.data.data | to_entries[] | "\(.key): \(.value)"'
            fi
            ;;
    esac
}

# Function to set GitHub Actions output
set_output() {
    local name="$1"
    local value="$2"
    
    if [[ -n "${GITHUB_OUTPUT}" ]]; then
        echo "${name}=${value}" >> "${GITHUB_OUTPUT}"
    else
        echo "::set-output name=${name}::${value}"
    fi
}

# Function to mask sensitive values in GitHub Actions logs
mask_value() {
    local value="$1"
    if [[ -n "${value}" ]]; then
        echo "::add-mask::${value}"
    fi
}

# Function to export secrets as environment variables
export_secrets() {
    local path="$1"
    local prefix="${2:-}"
    
    log "📦 Exporting secrets from ${path}..."
    
    ensure_vault_auth
    
    local secrets
    secrets=$(vault kv get -format=json "secret/${path}" | jq -r '.data.data | to_entries[] | "\(.key)=\(.value)"')
    
    while IFS='=' read -r key value; do
        if [[ -n "${key}" && -n "${value}" ]]; then
            local env_var="${prefix}${key}"
            export "${env_var}=${value}"
            mask_value "${value}"
            log "✅ Exported ${env_var}"
        fi
    done <<< "${secrets}"
}

# Function to load CloudYa specific secrets
load_cloudya_secrets() {
    log "🏢 Loading CloudYa environment secrets..."
    
    export_secrets "cloudya/environment" "CLOUDYA_"
    export_secrets "cloudya/database" "DB_"
    export_secrets "shared/llm-api-keys" ""
    
    # Set common CloudYa variables
    export CLOUDYA_ENVIRONMENT="${CLOUDYA_ENVIRONMENT:-production}"
    export VAULT_ADDR="${VAULT_ADDR:-https://vault.cloudya.net}"
}

# Function to get database connection string
get_database_url() {
    ensure_vault_auth
    
    local db_url
    db_url=$(vault kv get -field=database_url secret/cloudya/database 2>/dev/null)
    
    if [[ -n "${db_url}" ]]; then
        echo "${db_url}"
        mask_value "${db_url}"
    else
        log "❌ Could not retrieve database URL from Vault"
        exit 1
    fi
}

# Function to rotate secrets (for maintenance workflows)
rotate_secret() {
    local path="$1"
    local key="$2"
    local new_value="$3"
    
    ensure_vault_auth
    
    log "🔄 Rotating secret at ${path}/${key}..."
    
    # Get current secret
    local current_data
    current_data=$(vault kv get -format=json "secret/${path}" | jq -r '.data.data')
    
    # Update the specific key
    local updated_data
    updated_data=$(echo "${current_data}" | jq --arg key "${key}" --arg value "${new_value}" '.[$key] = $value')
    
    # Write back to Vault
    echo "${updated_data}" | vault kv put "secret/${path}" -
    
    log "✅ Secret ${key} rotated successfully"
    mask_value "${new_value}"
}

# Main command handling
case "${1:-}" in
    "get")
        get_secret "$2" "$3" "$4"
        ;;
    "export")
        export_secrets "$2" "$3"
        ;;
    "load-cloudya")
        load_cloudya_secrets
        ;;
    "database-url")
        get_database_url
        ;;
    "rotate")
        rotate_secret "$2" "$3" "$4"
        ;;
    "auth")
        ensure_vault_auth
        log "✅ Vault authentication verified"
        ;;
    *)
        cat << 'EOF'
Vault Helper for GitHub Actions Runner

Usage:
  vault-helper.sh get <path> [key] [format]     Get secret from Vault
  vault-helper.sh export <path> [prefix]        Export secrets as env vars
  vault-helper.sh load-cloudya                  Load CloudYa environment secrets
  vault-helper.sh database-url                  Get database connection URL
  vault-helper.sh rotate <path> <key> <value>   Rotate a secret
  vault-helper.sh auth                          Verify Vault authentication

Examples:
  vault-helper.sh get "github-runner/auth" "access_token"
  vault-helper.sh export "cloudya/environment" "CLOUDYA_"
  vault-helper.sh load-cloudya
  
Environment Variables:
  VAULT_ADDR        - Vault server address
  VAULT_ROLE_ID     - AppRole role ID
  VAULT_SECRET_ID   - AppRole secret ID
  VAULT_TOKEN       - Direct token (alternative to AppRole)
EOF
        exit 1
        ;;
esac