#!/bin/bash
set -e

# CloudYa GitHub Actions Runner Entrypoint
# Handles runner registration, Vault authentication, and startup

echo "🚀 Starting CloudYa GitHub Actions Runner..."
echo "Runner Version: $(cat /home/runner/actions-runner/.runner 2>/dev/null || echo 'Not configured')"
echo "Vault Integration: Enabled"
echo "Docker Support: Enabled"

# Function to log with timestamp
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

# Function to authenticate with Vault
authenticate_vault() {
    log "🔐 Authenticating with Vault..."
    
    # Check if in test mode
    if [[ "${TEST_MODE}" == "true" ]]; then
        log "🧪 Test mode: Using mock Vault authentication"
        export VAULT_TOKEN="test-root-token"
        echo "${VAULT_TOKEN}" > /home/runner/.vault/token
        return 0
    fi
    
    if [[ -n "${VAULT_ROLE_ID}" && -n "${VAULT_SECRET_ID}" ]]; then
        log "Using AppRole authentication"
        export VAULT_TOKEN=$(vault write -field=token auth/approle/login \
            role_id="${VAULT_ROLE_ID}" \
            secret_id="${VAULT_SECRET_ID}")
        
        if [[ $? -eq 0 && -n "${VAULT_TOKEN}" ]]; then
            log "✅ Successfully authenticated with Vault"
            echo "${VAULT_TOKEN}" > /home/runner/.vault/token
            return 0
        else
            log "❌ Failed to authenticate with Vault using AppRole"
            return 1
        fi
    elif [[ -n "${VAULT_TOKEN}" ]]; then
        log "Using provided VAULT_TOKEN"
        echo "${VAULT_TOKEN}" > /home/runner/.vault/token
        return 0
    else
        log "⚠️  No Vault authentication credentials provided"
        return 1
    fi
}

# Function to get GitHub token from Vault
get_github_token() {
    log "🔑 Retrieving GitHub token from Vault..."
    
    # In test mode, use environment variable directly
    if [[ "${TEST_MODE}" == "true" ]]; then
        log "🧪 Test mode: Using GitHub token from environment"
        if [[ -n "${GITHUB_ACCESS_TOKEN}" ]]; then
            log "✅ GitHub token available from environment"
            return 0
        else
            log "⚠️  No GitHub token provided in test mode"
            return 1
        fi
    fi
    
    if [[ -f "/home/runner/.vault/token" ]]; then
        export VAULT_TOKEN=$(cat /home/runner/.vault/token)
        
        # Try to get GitHub access token from Vault
        GITHUB_TOKEN=$(vault kv get -field=access_token secret/github-runner/auth 2>/dev/null || echo "")
        
        if [[ -n "${GITHUB_TOKEN}" ]]; then
            log "✅ Retrieved GitHub token from Vault"
            export GITHUB_ACCESS_TOKEN="${GITHUB_TOKEN}"
            return 0
        else
            log "⚠️  Could not retrieve GitHub token from Vault, using environment variable"
            return 1
        fi
    else
        log "⚠️  No Vault token available"
        return 1
    fi
}

# Function to get runner configuration from Vault
get_runner_config() {
    log "⚙️  Loading runner configuration from Vault..."
    
    if [[ -f "/home/runner/.vault/token" ]]; then
        export VAULT_TOKEN=$(cat /home/runner/.vault/token)
        
        # Get configuration values with defaults
        export RUNNER_NAME=$(vault kv get -field=runner_name secret/github-runner/config 2>/dev/null || echo "cloudya-runner-$(hostname)")
        export RUNNER_LABELS=$(vault kv get -field=runner_labels secret/github-runner/config 2>/dev/null || echo "cloudya,ubuntu,docker,vault")
        export RUNNER_GROUP=$(vault kv get -field=runner_group secret/github-runner/config 2>/dev/null || echo "cloudya-runners")
        export GITHUB_REPOSITORY_URL=$(vault kv get -field=repository_url secret/github-runner/auth 2>/dev/null || echo "")
        export GITHUB_ORGANIZATION_URL=$(vault kv get -field=organization_url secret/github-runner/auth 2>/dev/null || echo "")
        
        log "✅ Runner configuration loaded from Vault"
        log "   Name: ${RUNNER_NAME}"
        log "   Labels: ${RUNNER_LABELS}"
        log "   Group: ${RUNNER_GROUP}"
        return 0
    else
        log "⚠️  Using default configuration"
        export RUNNER_NAME="${RUNNER_NAME:-cloudya-runner-$(hostname)}"
        export RUNNER_LABELS="${RUNNER_LABELS:-cloudya,ubuntu,docker}"
        export RUNNER_GROUP="${RUNNER_GROUP:-default}"
        return 1
    fi
}

# Function to register the runner
register_runner() {
    log "📝 Registering GitHub Actions runner..."
    
    # Ensure we have required variables
    if [[ -z "${GITHUB_ACCESS_TOKEN}" ]]; then
        log "❌ GITHUB_ACCESS_TOKEN is required"
        exit 1
    fi
    
    if [[ -z "${GITHUB_REPOSITORY_URL}" && -z "${GITHUB_ORGANIZATION_URL}" ]]; then
        log "❌ Either GITHUB_REPOSITORY_URL or GITHUB_ORGANIZATION_URL is required"
        exit 1
    fi
    
    # Determine registration URL
    local REGISTRATION_URL
    if [[ -n "${GITHUB_ORGANIZATION_URL}" ]]; then
        REGISTRATION_URL="${GITHUB_ORGANIZATION_URL}"
        log "   Registering for organization: ${GITHUB_ORGANIZATION_URL}"
    else
        REGISTRATION_URL="${GITHUB_REPOSITORY_URL}"
        log "   Registering for repository: ${GITHUB_REPOSITORY_URL}"
    fi
    
    # Configure the runner
    ./config.sh --unattended \
        --url "${REGISTRATION_URL}" \
        --token "${GITHUB_ACCESS_TOKEN}" \
        --name "${RUNNER_NAME}" \
        --labels "${RUNNER_LABELS}" \
        --runnergroup "${RUNNER_GROUP}" \
        --work "/home/runner/work" \
        --replace \
        ${EPHEMERAL:+--ephemeral}
    
    if [[ $? -eq 0 ]]; then
        log "✅ Runner registered successfully"
        return 0
    else
        log "❌ Failed to register runner"
        exit 1
    fi
}

# Function to setup Docker socket access
setup_docker() {
    log "🐳 Setting up Docker access..."
    
    # Check if Docker socket is available
    if [[ -S "/var/run/docker.sock" ]]; then
        # Get Docker socket group
        DOCKER_GID=$(stat -c '%g' /var/run/docker.sock)
        
        # Add runner user to docker group with correct GID
        sudo groupmod -g "${DOCKER_GID}" docker 2>/dev/null || true
        sudo usermod -aG docker runner
        
        # Test Docker access
        if docker version >/dev/null 2>&1; then
            log "✅ Docker access configured successfully"
        else
            log "⚠️  Docker access may be limited"
        fi
    else
        log "⚠️  Docker socket not available"
    fi
}

# Function to cleanup on exit
cleanup() {
    log "🧹 Cleaning up..."
    if [[ -f "/home/runner/actions-runner/.runner" ]]; then
        log "Removing runner registration..."
        ./config.sh remove --unattended --token "${GITHUB_ACCESS_TOKEN}" || true
    fi
    exit 0
}

# Trap signals for graceful shutdown
trap cleanup SIGTERM SIGINT

# Main execution
main() {
    log "🚀 CloudYa GitHub Actions Runner Starting..."
    
    # Create necessary directories
    mkdir -p /home/runner/.vault
    mkdir -p /home/runner/work
    
    # Authenticate with Vault (optional, fallback to env vars)
    authenticate_vault || log "⚠️  Continuing without Vault authentication"
    
    # Get GitHub token from Vault or use environment
    get_github_token || log "⚠️  Using GitHub token from environment"
    
    # Get runner configuration from Vault or use defaults
    get_runner_config || log "⚠️  Using default runner configuration"
    
    # Setup Docker access
    setup_docker
    
    # Register the runner with GitHub
    register_runner
    
    # Start the runner
    log "🏃 Starting GitHub Actions runner..."
    log "   Listening for jobs on: ${GITHUB_REPOSITORY_URL}${GITHUB_ORGANIZATION_URL}"
    log "   Runner name: ${RUNNER_NAME}"
    log "   Labels: ${RUNNER_LABELS}"
    
    # Run the GitHub Actions runner
    exec ./run.sh
}

# Check if running as root (for Docker setup)
if [[ $(id -u) -eq 0 ]]; then
    log "⚠️  Running as root, switching to runner user..."
    exec sudo -u runner "$0" "$@"
fi

# Start main execution
main "$@"