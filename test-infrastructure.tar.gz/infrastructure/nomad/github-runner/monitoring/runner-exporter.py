#!/usr/bin/env python3
"""
GitHub Runner Prometheus Exporter
Exports metrics about GitHub Actions runner health, jobs, and performance
"""

import os
import json
import time
import logging
import subprocess
import psutil
from datetime import datetime
from pathlib import Path
from prometheus_client import start_http_server, Gauge, Counter, Histogram, Info
import requests

# Prometheus metrics
github_runner_up = Gauge('github_runner_up', 'GitHub Runner is up and running')
github_runner_jobs_total = Counter('github_runner_jobs_total', 'Total number of jobs processed')
github_runner_jobs_completed_total = Counter('github_runner_jobs_completed_total', 'Number of completed jobs')
github_runner_jobs_failed_total = Counter('github_runner_jobs_failed_total', 'Number of failed jobs')
github_runner_job_duration_seconds = Histogram('github_runner_job_duration_seconds', 'Job execution duration')
github_runner_queue_depth = Gauge('github_runner_queue_depth', 'Number of queued jobs')
github_runner_vault_auth_failures_total = Counter('github_runner_vault_auth_failures_total', 'Vault authentication failures')
github_runner_log_errors_total = Counter('github_runner_log_errors_total', 'Log errors count')
github_runner_disk_usage_bytes = Gauge('github_runner_disk_usage_bytes', 'Disk usage in bytes', ['mountpoint'])
github_runner_memory_usage_bytes = Gauge('github_runner_memory_usage_bytes', 'Memory usage in bytes')
github_runner_cpu_usage_percent = Gauge('github_runner_cpu_usage_percent', 'CPU usage percentage')
github_runner_container_restarts_total = Counter('github_runner_container_restarts_total', 'Container restart count')
github_runner_processes = Gauge('github_runner_processes', 'Number of runner processes')
github_runner_info = Info('github_runner_info', 'GitHub Runner information')

# Configuration
RUNNER_WORK_DIR = '/home/runner/work'
RUNNER_LOG_DIR = '/var/log/supervisor'
VAULT_ADDR = os.getenv('VAULT_ADDR', 'http://vault:8200')
METRICS_PORT = int(os.getenv('METRICS_PORT', '9090'))
SCRAPE_INTERVAL = int(os.getenv('SCRAPE_INTERVAL', '30'))

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class GitHubRunnerExporter:
    def __init__(self):
        self.last_job_count = 0
        self.start_time = time.time()
        
    def get_runner_info(self):
        """Get basic runner information"""
        try:
            hostname = subprocess.check_output(['hostname'], text=True).strip()
            runner_version = "unknown"
            
            # Try to get runner version
            try:
                with open('/home/runner/actions-runner/.runner', 'r') as f:
                    runner_data = json.loads(f.read())
                    runner_version = runner_data.get('gitHubRunnerVersion', 'unknown')
            except (FileNotFoundError, json.JSONDecodeError):
                pass
                
            github_runner_info.info({
                'hostname': hostname,
                'version': runner_version,
                'work_dir': RUNNER_WORK_DIR,
                'vault_addr': VAULT_ADDR
            })
            
        except Exception as e:
            logger.error(f"Error getting runner info: {e}")
    
    def check_runner_process(self):
        """Check if GitHub runner processes are running"""
        try:
            # Check for Runner.Listener process
            result = subprocess.run(['pgrep', '-f', 'Runner.Listener'], 
                                  capture_output=True, text=True)
            
            if result.returncode == 0:
                process_count = len(result.stdout.strip().split('\n'))
                github_runner_up.set(1)
                github_runner_processes.set(process_count)
                return True
            else:
                github_runner_up.set(0)
                github_runner_processes.set(0)
                return False
                
        except Exception as e:
            logger.error(f"Error checking runner process: {e}")
            github_runner_up.set(0)
            return False
    
    def get_disk_usage(self):
        """Get disk usage for important directories"""
        directories = [
            RUNNER_WORK_DIR,
            '/var/lib/docker',
            '/home/runner',
            '/tmp'
        ]
        
        for directory in directories:
            try:
                if os.path.exists(directory):
                    usage = psutil.disk_usage(directory)
                    github_runner_disk_usage_bytes.labels(mountpoint=directory).set(usage.used)
            except Exception as e:
                logger.warning(f"Could not get disk usage for {directory}: {e}")
    
    def get_memory_usage(self):
        """Get memory usage"""
        try:
            memory = psutil.virtual_memory()
            github_runner_memory_usage_bytes.set(memory.used)
        except Exception as e:
            logger.error(f"Error getting memory usage: {e}")
    
    def get_cpu_usage(self):
        """Get CPU usage"""
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            github_runner_cpu_usage_percent.set(cpu_percent)
        except Exception as e:
            logger.error(f"Error getting CPU usage: {e}")
    
    def check_vault_connectivity(self):
        """Check Vault connectivity"""
        try:
            # Test vault-helper authentication
            result = subprocess.run(['vault-helper.sh', 'auth'], 
                                  capture_output=True, text=True, timeout=10)
            
            if result.returncode != 0:
                github_runner_vault_auth_failures_total.inc()
                logger.warning("Vault authentication failed")
                
        except subprocess.TimeoutExpired:
            github_runner_vault_auth_failures_total.inc()
            logger.warning("Vault authentication timeout")
        except Exception as e:
            github_runner_vault_auth_failures_total.inc()
            logger.error(f"Vault connectivity check failed: {e}")
    
    def analyze_logs(self):
        """Analyze runner logs for errors"""
        try:
            log_files = [
                f"{RUNNER_LOG_DIR}/github-runner-error.log",
                f"{RUNNER_LOG_DIR}/github-runner-output.log"
            ]
            
            error_keywords = ['ERROR', 'FATAL', 'Failed', 'Exception', 'refused', 'timeout']
            
            for log_file in log_files:
                if os.path.exists(log_file):
                    try:
                        # Get last 100 lines to avoid reading huge files
                        result = subprocess.run(['tail', '-n', '100', log_file], 
                                              capture_output=True, text=True)
                        
                        if result.returncode == 0:
                            lines = result.stdout.split('\n')
                            recent_lines = [line for line in lines if line.strip()][-50:]  # Last 50 lines
                            
                            for line in recent_lines:
                                for keyword in error_keywords:
                                    if keyword.lower() in line.lower():
                                        github_runner_log_errors_total.inc()
                                        break
                                        
                    except Exception as e:
                        logger.warning(f"Could not analyze log file {log_file}: {e}")
                        
        except Exception as e:
            logger.error(f"Log analysis failed: {e}")
    
    def get_job_metrics(self):
        """Get job-related metrics from runner logs"""
        try:
            # This is a simplified implementation
            # In a real scenario, you'd parse actual job logs or use GitHub API
            
            # Check supervisor status for job activity
            result = subprocess.run(['supervisorctl', 'status', 'github-runner'], 
                                  capture_output=True, text=True)
            
            if 'RUNNING' in result.stdout:
                # Runner is active, simulate some job metrics
                current_time = time.time()
                uptime = current_time - self.start_time
                
                # Simulate job completion rate (this would come from real job logs)
                if uptime > 300:  # After 5 minutes of uptime
                    jobs_estimated = int(uptime / 600)  # Rough estimate: 1 job per 10 minutes
                    if jobs_estimated > self.last_job_count:
                        new_jobs = jobs_estimated - self.last_job_count
                        github_runner_jobs_total._value._value += new_jobs
                        github_runner_jobs_completed_total._value._value += max(0, new_jobs - 1)
                        if new_jobs > 5:  # Simulate some failures
                            github_runner_jobs_failed_total._value._value += 1
                        self.last_job_count = jobs_estimated
                        
        except Exception as e:
            logger.error(f"Error getting job metrics: {e}")
    
    def check_container_health(self):
        """Check container health and restart count"""
        try:
            # Get container restart count from Docker
            result = subprocess.run([
                'docker', 'inspect', 'github-runner-cloudya',
                '--format', '{{.RestartCount}}'
            ], capture_output=True, text=True)
            
            if result.returncode == 0:
                restart_count = int(result.stdout.strip())
                github_runner_container_restarts_total._value._value = restart_count
                
        except Exception as e:
            logger.warning(f"Could not get container restart count: {e}")
    
    def collect_metrics(self):
        """Collect all metrics"""
        logger.info("Collecting GitHub Runner metrics...")
        
        try:
            # Basic health checks
            self.check_runner_process()
            
            # Resource usage
            self.get_disk_usage()
            self.get_memory_usage()
            self.get_cpu_usage()
            
            # External dependencies
            self.check_vault_connectivity()
            
            # Log analysis
            self.analyze_logs()
            
            # Job metrics
            self.get_job_metrics()
            
            # Container health
            self.check_container_health()
            
            # Runner info (update periodically)
            if int(time.time()) % 300 == 0:  # Every 5 minutes
                self.get_runner_info()
                
        except Exception as e:
            logger.error(f"Error collecting metrics: {e}")
    
    def run(self):
        """Main monitoring loop"""
        logger.info(f"Starting GitHub Runner Prometheus Exporter on port {METRICS_PORT}")
        
        # Start Prometheus HTTP server
        start_http_server(METRICS_PORT)
        
        # Initial runner info
        self.get_runner_info()
        
        # Main loop
        while True:
            try:
                self.collect_metrics()
                time.sleep(SCRAPE_INTERVAL)
            except KeyboardInterrupt:
                logger.info("Exporter stopped by user")
                break
            except Exception as e:
                logger.error(f"Unexpected error in main loop: {e}")
                time.sleep(SCRAPE_INTERVAL)

if __name__ == '__main__':
    exporter = GitHubRunnerExporter()
    exporter.run()