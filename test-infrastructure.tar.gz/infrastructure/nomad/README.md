# Nomad Vault Infrastructure

This directory contains comprehensive Nomad configurations and deployment scripts for HashiCorp Vault across multiple environments (development, staging, production).

## 📁 Directory Structure

```
infrastructure/nomad/
├── jobs/                           # Nomad job specifications
│   ├── develop/
│   │   └── vault.nomad            # Development environment job
│   ├── staging/
│   │   └── vault.nomad            # Staging environment job
│   └── production/
│       └── vault.nomad            # Production environment job
├── config/                         # Nomad configuration files
│   ├── nomad-client.hcl           # Client configuration
│   └── nomad-server.hcl           # Server configuration
├── scripts/                        # Deployment and management scripts
│   ├── bootstrap-vault.sh         # Main deployment script
│   ├── deploy-environment.sh      # Environment-specific deployment
│   ├── setup-nomad-volumes.sh     # Volume setup script
│   └── vault-health-monitor.sh    # Health monitoring script
└── README.md                       # This file
```

## 🚀 Quick Start

### 1. Prerequisites

Ensure you have the following installed:
- [Nomad](https://www.nomadproject.io/downloads) (v1.7+)
- [Vault CLI](https://www.vaultproject.io/downloads) (optional, for management)
- [jq](https://stedolan.jq.io/) (for JSON processing)
- curl (for health checks)

### 2. Setup Nomad Volumes

First, create the necessary host volumes for Vault data persistence:

```bash
# Setup volumes for all environments
sudo ./scripts/setup-nomad-volumes.sh --environment all

# Or setup for specific environment
sudo ./scripts/setup-nomad-volumes.sh --environment develop
```

### 3. Configure Nomad Client

Add the generated volume configuration to your Nomad client configuration:

```bash
# Add the generated config to your nomad client
cat config/nomad-volumes.hcl >> /etc/nomad.d/client.hcl

# Restart Nomad client
sudo systemctl restart nomad
```

### 4. Deploy Vault

Deploy Vault to your desired environment:

```bash
# Deploy to development
./scripts/deploy-environment.sh --environment develop

# Deploy to staging
./scripts/deploy-environment.sh --environment staging

# Deploy to production (requires careful consideration)
./scripts/deploy-environment.sh --environment production
```

### 5. Monitor Health

Monitor the health of your Vault deployments:

```bash
# Check all environments
./scripts/vault-health-monitor.sh --environment all

# Continuous monitoring
./scripts/vault-health-monitor.sh --watch --interval 30
```

## 🏗️ Environment Configurations

### Development Environment

**Job Name:** `vault-develop`
**Endpoint:** `http://localhost:8200`

Features:
- Auto-initialization and unsealing
- No TLS (simplified for development)
- Lower resource requirements
- Development-friendly policies
- File-based storage

### Staging Environment

**Job Name:** `vault-staging`
**Endpoint:** `https://localhost:8210`

Features:
- Manual initialization (production-like)
- Self-signed TLS certificates
- Production-similar policies
- Enhanced logging and monitoring
- File-based storage

### Production Environment

**Job Name:** `vault-production`
**Endpoint:** `https://localhost:8220`

Features:
- High availability (3 replicas)
- Consul backend storage
- AWS KMS auto-unseal
- Production TLS certificates
- Comprehensive audit logging
- Automated backups
- Enhanced security policies

## 📋 Detailed Usage

### Bootstrap Script

The main bootstrap script provides comprehensive deployment automation:

```bash
# Basic deployment
./scripts/bootstrap-vault.sh --environment develop

# With custom token
./scripts/bootstrap-vault.sh --environment staging --token s.xyz123

# Dry run (preview changes)
./scripts/bootstrap-vault.sh --environment production --dry-run

# Auto-approve (no prompts)
./scripts/bootstrap-vault.sh --environment develop --yes
```

### Environment Deployment Script

More granular control over deployments:

```bash
# Deploy
./scripts/deploy-environment.sh --environment develop

# Check status
./scripts/deploy-environment.sh --environment staging --action status

# Restart
./scripts/deploy-environment.sh --environment production --action restart

# Destroy (DANGEROUS)
./scripts/deploy-environment.sh --environment develop --action destroy
```

### Volume Setup Script

Manage Nomad host volumes:

```bash
# Setup all environments
sudo ./scripts/setup-nomad-volumes.sh --environment all

# Custom volume path
sudo ./scripts/setup-nomad-volumes.sh --path /custom/path

# Cleanup existing volumes (DANGEROUS)
sudo ./scripts/setup-nomad-volumes.sh --cleanup --environment develop

# Dry run
./scripts/setup-nomad-volumes.sh --dry-run
```

### Health Monitoring Script

Comprehensive health monitoring:

```bash
# Single check
./scripts/vault-health-monitor.sh --environment production

# Watch mode
./scripts/vault-health-monitor.sh --watch --interval 60

# JSON output
./scripts/vault-health-monitor.sh --format json

# Prometheus metrics
./scripts/vault-health-monitor.sh --format prometheus

# With alerts
./scripts/vault-health-monitor.sh --alert-webhook https://hooks.slack.com/your/webhook

# Log to file
./scripts/vault-health-monitor.sh --log-file /var/log/vault-health.log
```

## 🔧 Configuration Details

### Nomad Job Features

All Vault jobs include:
- **Persistent Storage:** Host volumes for data persistence
- **Health Checks:** HTTP-based health monitoring
- **Resource Management:** CPU and memory limits
- **Service Discovery:** Consul service registration
- **Restart Policies:** Automatic recovery from failures
- **Update Strategies:** Zero-downtime deployments

### Security Features

- **TLS Encryption:** HTTPS endpoints for staging/production
- **Auto-unseal:** AWS KMS integration for production
- **Audit Logging:** Comprehensive audit trails
- **Network Security:** Bridge mode networking
- **Secret Management:** Vault-native secret storage
- **Access Controls:** Role-based policies

### Storage Backends

- **Development:** File storage (`/vault/data`)
- **Staging:** File storage with enhanced backup
- **Production:** Consul storage for HA

## 🔒 Security Considerations

### Development Environment

- ⚠️ **No TLS:** HTTP only, suitable for local development
- ⚠️ **Auto-unseal:** Automatic for convenience
- ⚠️ **Permissive:** Relaxed security for ease of use

### Staging Environment

- ✅ **TLS:** Self-signed certificates
- ✅ **Manual unsealing:** Production-like procedures
- ✅ **Enhanced policies:** Security testing environment

### Production Environment

- ✅ **Production TLS:** CA-signed certificates required
- ✅ **Auto-unseal:** AWS KMS integration
- ✅ **High Availability:** Multi-node cluster
- ✅ **Audit logging:** Comprehensive security logs
- ✅ **Backup strategies:** Automated data protection
- ✅ **Network security:** Encrypted communication

## 🚨 Production Deployment Checklist

Before deploying to production:

- [ ] **TLS Certificates:** Install proper CA-signed certificates
- [ ] **AWS KMS:** Configure KMS key for auto-unseal
- [ ] **Consul Backend:** Setup Consul cluster for storage
- [ ] **Network Security:** Configure firewalls and network policies
- [ ] **Monitoring:** Setup monitoring and alerting
- [ ] **Backup Strategy:** Configure automated backups
- [ ] **Disaster Recovery:** Test recovery procedures
- [ ] **Security Audit:** Complete security review
- [ ] **Key Management:** Plan for key distribution and recovery
- [ ] **Compliance:** Ensure regulatory compliance

## 🔧 Troubleshooting

### Common Issues

**Job Won't Start:**
```bash
# Check job validation
nomad job validate jobs/develop/vault.nomad

# Check node resources
nomad node status

# Check volume permissions
ls -la /opt/nomad/volumes/
```

**Vault Unreachable:**
```bash
# Check allocation status
nomad job status vault-develop

# View logs
nomad alloc logs $(nomad job allocs vault-develop -json | jq -r '.[0].ID') vault

# Check network connectivity
curl http://localhost:8200/v1/sys/health
```

**Permission Issues:**
```bash
# Fix volume permissions
sudo ./scripts/setup-nomad-volumes.sh --environment develop

# Check Nomad client config
nomad node config
```

---

**Version:** 1.0.0  
**Last Updated:** 2025-08-25  
**Vault Version:** 1.17.6  
**Nomad Version:** 1.7.0+