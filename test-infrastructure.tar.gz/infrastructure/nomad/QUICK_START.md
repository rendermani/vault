# Cloudya Quick Start Guide

## 🚀 Starting the Infrastructure

### Startup Sequence

```mermaid
sequenceDiagram
    participant Admin
    participant PostgreSQL
    participant Vault
    participant Traefik
    participant Services as Web Services

    Admin->>PostgreSQL: 1. Start PostgreSQL
    PostgreSQL->>PostgreSQL: Initialize Database
    
    Admin->>Vault: 2. Start Vault
    Vault->>PostgreSQL: Connect to Database
    
    note over Vault: Vault starts SEALED
    
    Admin->>Vault: 3. Unseal Vault (3 keys)
    Vault->>Vault: Become operational
    
    Admin->>Traefik: 4. Start Traefik
    Traefik->>Vault: Health check
    Traefik->>Services: Route traffic
    
    note over Admin: All services ready!
    Admin->>Services: Access via https://*.loc
```

### 1. Start Core Services
```bash
# Start Vault and PostgreSQL
docker-compose -f vault/docker-compose.vault.yml up -d

# Wait for Vault to be ready, then unseal it (if needed)
# Use the unseal keys from vault-init.txt

# Start Traefik
docker-compose -f traefik/docker-compose.traefik.yml up -d
```

### 2. Access Services
- **Traefik Dashboard**: https://traefik.loc (admin/secure123)
- **Vault UI**: https://vault.loc (use root token from vault-init.txt)
- **OwnCloud**: https://owncloud.loc

### 3. Vault Unsealing (if Vault was restarted)
```bash
# Use any 3 of the 5 unseal keys from vault-init.txt
docker exec vault sh -c 'export VAULT_ADDR=http://127.0.0.1:8200 && vault operator unseal [KEY1]'
docker exec vault sh -c 'export VAULT_ADDR=http://127.0.0.1:8200 && vault operator unseal [KEY2]'
docker exec vault sh -c 'export VAULT_ADDR=http://127.0.0.1:8200 && vault operator unseal [KEY3]'
```

## 🛠️ Troubleshooting

### Troubleshooting Decision Tree

```mermaid
flowchart TD
    A[🚨 Service Not Working] --> B{Which Service?}
    
    B -->|Traefik| C[Check Traefik Dashboard<br/>https://traefik.loc]
    B -->|Vault| D[Check Vault Status<br/>https://vault.loc]
    B -->|General| E[Check Docker Containers]
    
    C --> C1{Dashboard Accessible?}
    C1 -->|No| C2[Check DNS/Hosts file<br/>127.0.0.1 traefik.loc]
    C1 -->|403 Auth| C3[Check Password<br/>Run update script]
    C1 -->|Yes| C4[Check Service Routes<br/>in Dashboard]
    
    D --> D1{Vault UI Loading?}
    D1 -->|No| D2[Check if Vault is Unsealed<br/>docker logs vault]
    D1 -->|Yes| D3[Check Vault Token<br/>Use token from vault-init.txt]
    
    D2 --> D4[Unseal Vault<br/>Use 3 keys from vault-init.txt]
    
    E --> E1[docker ps -a<br/>Check container status]
    E1 --> E2{All Running?}
    E2 -->|No| E3[docker-compose up -d<br/>Start missing services]
    E2 -->|Yes| E4[Check Networks<br/>docker network ls]
    
    style A fill:#ffebee
    style C2 fill:#fff3e0
    style C3 fill:#fff3e0
    style D4 fill:#fff3e0
    style E3 fill:#fff3e0
```

### Vault Agent Issues
If vault-agent is not rendering secrets:
```bash
# Check vault-agent logs
docker logs vault-agent

# Restart vault-agent
docker-compose -f vault/docker-compose.vault.yml restart vault-agent
```

### DNS Issues
Make sure these entries are in your `/etc/hosts`:
```
127.0.0.1 traefik.loc
127.0.0.1 vault.loc  
127.0.0.1 owncloud.loc
```

### Certificate Issues
If you get certificate errors:
```bash
# Regenerate mkcert certificates
cd traefik/certs
mkcert "*.loc" localhost 127.0.0.1
```

## 🔒 Security Reminders

- Keep `vault-init.txt` secure and private
- Rotate the Vault root token in production
- Monitor access logs
- Backup Vault data regularly

## 📝 Development Notes

- All passwords are stored in Vault, not in configuration files
- Use the Vault UI to manage secrets
- Traefik automatically routes based on domain names
- All communication between services is encrypted
