#!/bin/bash
set -e

# Setup Host Volumes for Nomad Jobs
# This script creates and configures the host volumes needed for Vault and Traefik

echo "Setting up Nomad host volumes for Vault and Traefik..."

# Base directory for Nomad volumes
VOLUME_BASE="/opt/nomad/volumes"

# Create base directory
sudo mkdir -p "$VOLUME_BASE"

echo "Creating Vault volumes..."

# Vault volumes
sudo mkdir -p "$VOLUME_BASE/vault-data"
sudo mkdir -p "$VOLUME_BASE/vault-config"
sudo mkdir -p "$VOLUME_BASE/vault-logs"
sudo mkdir -p "$VOLUME_BASE/vault-certs"

# Set Vault permissions
sudo chmod 700 "$VOLUME_BASE/vault-data"
sudo chmod 755 "$VOLUME_BASE/vault-config"
sudo chmod 755 "$VOLUME_BASE/vault-logs"
sudo chmod 600 "$VOLUME_BASE/vault-certs"

# Create vault user if it doesn't exist
if ! id vault >/dev/null 2>&1; then
    sudo useradd -r -s /bin/false vault
    echo "Created vault user"
fi

# Set Vault ownership
sudo chown -R vault:vault "$VOLUME_BASE/vault-"*

echo "Creating Traefik volumes..."

# Traefik volumes
sudo mkdir -p "$VOLUME_BASE/traefik-certs"
sudo mkdir -p "$VOLUME_BASE/traefik-config/dynamic"

# Initialize ACME storage for Let's Encrypt
if [ ! -f "$VOLUME_BASE/traefik-certs/acme.json" ]; then
    echo '{}' | sudo tee "$VOLUME_BASE/traefik-certs/acme.json" > /dev/null
    sudo chmod 600 "$VOLUME_BASE/traefik-certs/acme.json"
    echo "Created ACME storage file"
fi

# Set Traefik permissions
sudo chmod 700 "$VOLUME_BASE/traefik-certs"
sudo chmod 755 "$VOLUME_BASE/traefik-config"

# Create traefik user if it doesn't exist
if ! id traefik >/dev/null 2>&1; then
    sudo useradd -r -s /bin/false traefik
    echo "Created traefik user"
fi

# Set Traefik ownership
sudo chown -R traefik:traefik "$VOLUME_BASE/traefik-"*

echo "Creating Nomad client volume configuration..."

# Create volume configuration for Nomad client
NOMAD_CONFIG_DIR="/etc/nomad.d"
sudo mkdir -p "$NOMAD_CONFIG_DIR"

sudo tee "$NOMAD_CONFIG_DIR/volumes.hcl" > /dev/null <<EOF
# Host volume configuration for Nomad client

client {
  host_volume "vault-data" {
    path      = "$VOLUME_BASE/vault-data"
    read_only = false
  }

  host_volume "vault-config" {
    path      = "$VOLUME_BASE/vault-config"
    read_only = false
  }

  host_volume "vault-logs" {
    path      = "$VOLUME_BASE/vault-logs"
    read_only = false
  }

  host_volume "vault-certs" {
    path      = "$VOLUME_BASE/vault-certs"
    read_only = true
  }

  host_volume "traefik-certs" {
    path      = "$VOLUME_BASE/traefik-certs"
    read_only = false
  }

  host_volume "traefik-config" {
    path      = "$VOLUME_BASE/traefik-config"
    read_only = false
  }
}
EOF

echo "Volume setup complete!"
echo ""
echo "Created volumes:"
echo "  Vault:"
echo "    - $VOLUME_BASE/vault-data (vault:vault, 700)"
echo "    - $VOLUME_BASE/vault-config (vault:vault, 755)"
echo "    - $VOLUME_BASE/vault-logs (vault:vault, 755)"
echo "    - $VOLUME_BASE/vault-certs (vault:vault, 600)"
echo ""
echo "  Traefik:"
echo "    - $VOLUME_BASE/traefik-certs (traefik:traefik, 700)"
echo "    - $VOLUME_BASE/traefik-config (traefik:traefik, 755)"
echo ""
echo "Next steps:"
echo "1. Add SSL certificates to $VOLUME_BASE/vault-certs/"
echo "2. Restart Nomad client to load volume configuration: sudo systemctl restart nomad"
echo "3. Deploy jobs: nomad job run vault-production.nomad && nomad job run traefik-production.nomad"
echo ""
echo "Required certificates for Vault:"
echo "  - vault.crt (Vault server certificate)"
echo "  - vault.key (Vault server private key)"  
echo "  - vault-ca.pem (CA certificate for verification)"