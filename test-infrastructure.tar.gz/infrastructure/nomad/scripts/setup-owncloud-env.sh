#!/bin/bash

# OwnCloud Environment Setup Script
# Retrieves passwords from Vault and creates environment file

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}Setting up OwnCloud environment variables...${NC}"

# Get credentials from Vault
VAULT_TOKEN=${VAULT_TOKEN:-hvs.G1bdMlrMXfYt2GMAKICOhaGQ}

# Retrieve secrets
MYSQL_ROOT_PASSWORD=$(docker exec -e VAULT_TOKEN=$VAULT_TOKEN vault-cloudya-final vault kv get -field=mysql_root_password secret/development/owncloud)
OWNCLOUD_DB_PASSWORD=$(docker exec -e VAULT_TOKEN=$VAULT_TOKEN vault-cloudya-final vault kv get -field=owncloud_db_password secret/development/owncloud)
OWNCLOUD_ADMIN_PASSWORD=$(docker exec -e VAULT_TOKEN=$VAULT_TOKEN vault-cloudya-final vault kv get -field=owncloud_admin_password secret/development/owncloud)

# Create .env file
cat > /opt/cloudya/.env.owncloud << EOF
MYSQL_ROOT_PASSWORD=${MYSQL_ROOT_PASSWORD}
OWNCLOUD_DB_PASSWORD=${OWNCLOUD_DB_PASSWORD}
OWNCLOUD_ADMIN_PASSWORD=${OWNCLOUD_ADMIN_PASSWORD}
EOF

chmod 600 /opt/cloudya/.env.owncloud

echo -e "${GREEN}✅ OwnCloud environment configured${NC}"
echo "Admin password: ${OWNCLOUD_ADMIN_PASSWORD}"