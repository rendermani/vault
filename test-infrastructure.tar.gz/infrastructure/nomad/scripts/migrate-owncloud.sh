#!/bin/bash

# OwnCloud Migration Script
# Migrates 822GB of OwnCloud data from old.cloudya.net to new server

set -e

# Configuration
OLD_SERVER="old.cloudya.net"
NEW_SERVER="65.109.81.169"
STORAGE_BOX_HOST="${STORAGE_BOX_HOST:-}"
STORAGE_BOX_USER="${STORAGE_BOX_USER:-}"
STORAGE_BOX_PASS="${STORAGE_BOX_PASS:-}"
OWNCLOUD_DATA_PATH="/var/lib/docker/volumes/owncloud_files"
MYSQL_CONTAINER="owncloud_db_1"
OWNCLOUD_CONTAINER="owncloud_owncloud_1"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo "🚀 OwnCloud Migration Tool"
echo "=========================="
echo ""
echo "Data size: 822GB"
echo "From: $OLD_SERVER"
echo "To: $NEW_SERVER (via Storage Box)"
echo ""

# Function to check storage box credentials
check_storage_box() {
    echo -e "${BLUE}Checking Storage Box credentials...${NC}"
    if [ -z "$STORAGE_BOX_HOST" ] || [ -z "$STORAGE_BOX_USER" ]; then
        echo -e "${YELLOW}Storage Box credentials not set!${NC}"
        echo "Please provide:"
        read -p "Storage Box Host (e.g., uXXXXX.your-storagebox.de): " STORAGE_BOX_HOST
        read -p "Storage Box Username: " STORAGE_BOX_USER
        read -s -p "Storage Box Password: " STORAGE_BOX_PASS
        echo ""
        
        # Store in Vault
        echo -e "${BLUE}Storing credentials in Vault...${NC}"
        ssh root@$NEW_SERVER "docker exec -e VAULT_TOKEN=$VAULT_TOKEN vault-cloudya-final vault kv put secret/development/storage-box \
            host=$STORAGE_BOX_HOST \
            username=$STORAGE_BOX_USER \
            password=$STORAGE_BOX_PASS"
    fi
}

# Step 1: Prepare old server
prepare_old_server() {
    echo -e "${BLUE}Step 1: Preparing old server...${NC}"
    
    # Stop OwnCloud to ensure data consistency
    ssh root@$OLD_SERVER "docker stop $OWNCLOUD_CONTAINER || true"
    
    # Dump MySQL database
    echo "Dumping OwnCloud database..."
    ssh root@$OLD_SERVER "docker exec $MYSQL_CONTAINER mysqldump -uroot -p\$MYSQL_ROOT_PASSWORD owncloud > /tmp/owncloud_db.sql"
    
    echo -e "${GREEN}✓ Old server prepared${NC}"
}

# Step 2: Setup Storage Box mount
setup_storage_box() {
    echo -e "${BLUE}Step 2: Setting up Storage Box mount...${NC}"
    
    # Install sshfs if needed
    ssh root@$OLD_SERVER "apt-get update && apt-get install -y sshfs"
    ssh root@$NEW_SERVER "apt-get update && apt-get install -y sshfs"
    
    # Create mount point
    ssh root@$OLD_SERVER "mkdir -p /mnt/storage-box"
    ssh root@$NEW_SERVER "mkdir -p /mnt/storage-box"
    
    # Mount storage box on old server
    echo "Mounting storage box on old server..."
    ssh root@$OLD_SERVER "echo '$STORAGE_BOX_PASS' | sshfs -o password_stdin,allow_other,reconnect,ServerAliveInterval=15 \
        $STORAGE_BOX_USER@$STORAGE_BOX_HOST:/ /mnt/storage-box"
    
    echo -e "${GREEN}✓ Storage Box mounted${NC}"
}

# Step 3: Transfer data using rsync with progress
transfer_data() {
    echo -e "${BLUE}Step 3: Transferring 822GB of data...${NC}"
    echo -e "${YELLOW}This will take several hours!${NC}"
    
    # Create backup directory with timestamp
    BACKUP_DIR="owncloud-backup-$(date +%Y%m%d-%H%M%S)"
    ssh root@$OLD_SERVER "mkdir -p /mnt/storage-box/$BACKUP_DIR"
    
    # Transfer OwnCloud files (822GB)
    echo "Transferring OwnCloud files..."
    ssh root@$OLD_SERVER "rsync -avzP --stats \
        $OWNCLOUD_DATA_PATH/ \
        /mnt/storage-box/$BACKUP_DIR/owncloud_files/"
    
    # Transfer database dump
    echo "Transferring database..."
    ssh root@$OLD_SERVER "cp /tmp/owncloud_db.sql /mnt/storage-box/$BACKUP_DIR/"
    
    # Transfer docker-compose config
    echo "Transferring configuration..."
    ssh root@$OLD_SERVER "docker inspect $OWNCLOUD_CONTAINER > /mnt/storage-box/$BACKUP_DIR/owncloud_config.json"
    
    echo -e "${GREEN}✓ Data transferred to Storage Box${NC}"
    echo "Backup location: /mnt/storage-box/$BACKUP_DIR"
}

# Step 4: Setup new OwnCloud installation
setup_new_owncloud() {
    echo -e "${BLUE}Step 4: Setting up OwnCloud on new server...${NC}"
    
    # Mount storage box on new server
    echo "Mounting storage box on new server..."
    ssh root@$NEW_SERVER "echo '$STORAGE_BOX_PASS' | sshfs -o password_stdin,allow_other,reconnect,ServerAliveInterval=15 \
        $STORAGE_BOX_USER@$STORAGE_BOX_HOST:/ /mnt/storage-box"
    
    # Create docker-compose for OwnCloud
    cat > /tmp/owncloud-compose.yml <<EOF
version: '3.8'

networks:
  default:
    name: traefik
    external: true

volumes:
  owncloud_files:
    driver: local
  owncloud_mysql:
    driver: local
  owncloud_redis:
    driver: local

services:
  owncloud:
    image: owncloud/server:latest
    container_name: owncloud-new
    restart: always
    depends_on:
      - owncloud-db
      - owncloud-redis
    environment:
      - OWNCLOUD_DOMAIN=owncloud.cloudya.net
      - OWNCLOUD_DB_TYPE=mysql
      - OWNCLOUD_DB_NAME=owncloud
      - OWNCLOUD_DB_USERNAME=owncloud
      - OWNCLOUD_DB_PASSWORD=\${OWNCLOUD_DB_PASSWORD}
      - OWNCLOUD_DB_HOST=owncloud-db
      - OWNCLOUD_ADMIN_USERNAME=admin
      - OWNCLOUD_ADMIN_PASSWORD=\${OWNCLOUD_ADMIN_PASSWORD}
      - OWNCLOUD_REDIS_ENABLED=true
      - OWNCLOUD_REDIS_HOST=owncloud-redis
    volumes:
      - owncloud_files:/mnt/data
    labels:
      - "traefik.enable=true"
      - "traefik.http.routers.owncloud.rule=Host(\`owncloud.cloudya.net\`)"
      - "traefik.http.routers.owncloud.entrypoints=websecure"
      - "traefik.http.routers.owncloud.tls.certresolver=letsencrypt"
      - "traefik.http.services.owncloud.loadbalancer.server.port=8080"

  owncloud-db:
    image: mariadb:10.11
    container_name: owncloud-db-new
    restart: always
    environment:
      - MYSQL_ROOT_PASSWORD=\${MYSQL_ROOT_PASSWORD}
      - MYSQL_DATABASE=owncloud
      - MYSQL_USER=owncloud
      - MYSQL_PASSWORD=\${OWNCLOUD_DB_PASSWORD}
    volumes:
      - owncloud_mysql:/var/lib/mysql

  owncloud-redis:
    image: redis:7-alpine
    container_name: owncloud-redis-new
    restart: always
    volumes:
      - owncloud_redis:/data
EOF
    
    # Copy compose file to new server
    scp /tmp/owncloud-compose.yml root@$NEW_SERVER:/opt/cloudya/docker-compose-owncloud.yml
    
    echo -e "${GREEN}✓ OwnCloud setup prepared${NC}"
}

# Step 5: Restore data on new server
restore_data() {
    echo -e "${BLUE}Step 5: Restoring data on new server...${NC}"
    
    # Find latest backup
    LATEST_BACKUP=$(ssh root@$NEW_SERVER "ls -t /mnt/storage-box/ | grep owncloud-backup | head -1")
    
    if [ -z "$LATEST_BACKUP" ]; then
        echo -e "${RED}No backup found on storage box!${NC}"
        exit 1
    fi
    
    echo "Using backup: $LATEST_BACKUP"
    
    # Start database first
    ssh root@$NEW_SERVER "cd /opt/cloudya && \
        MYSQL_ROOT_PASSWORD=\$(openssl rand -base64 24) \
        OWNCLOUD_DB_PASSWORD=\$(openssl rand -base64 24) \
        docker compose -f docker-compose-owncloud.yml up -d owncloud-db"
    
    # Wait for database
    sleep 10
    
    # Restore database
    echo "Restoring database..."
    ssh root@$NEW_SERVER "docker exec -i owncloud-db-new mysql -uroot -p\$MYSQL_ROOT_PASSWORD owncloud < /mnt/storage-box/$LATEST_BACKUP/owncloud_db.sql"
    
    # Restore files
    echo "Restoring files (this will take time)..."
    ssh root@$NEW_SERVER "rsync -avzP /mnt/storage-box/$LATEST_BACKUP/owncloud_files/ /var/lib/docker/volumes/owncloud_files/"
    
    # Start OwnCloud
    ssh root@$NEW_SERVER "cd /opt/cloudya && docker compose -f docker-compose-owncloud.yml up -d"
    
    echo -e "${GREEN}✓ Data restored${NC}"
}

# Main execution
main() {
    echo "Starting OwnCloud migration..."
    
    check_storage_box
    prepare_old_server
    setup_storage_box
    transfer_data
    setup_new_owncloud
    restore_data
    
    echo ""
    echo -e "${GREEN}🎉 Migration Complete!${NC}"
    echo "OwnCloud is now available at: https://owncloud.cloudya.net"
    echo ""
    echo "Next steps:"
    echo "1. Test the new installation"
    echo "2. Update DNS if needed"
    echo "3. Remove old server data after verification"
}

# Handle arguments
case "$1" in
    check)
        check_storage_box
        ;;
    prepare)
        prepare_old_server
        ;;
    transfer)
        transfer_data
        ;;
    setup)
        setup_new_owncloud
        ;;
    restore)
        restore_data
        ;;
    *)
        main
        ;;
esac