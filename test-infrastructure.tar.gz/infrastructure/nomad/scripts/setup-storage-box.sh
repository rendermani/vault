#!/bin/bash

# Storage Box Setup Script
# Sets up Hetzner Storage Box connection for OwnCloud migration

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo "🔧 Hetzner Storage Box Setup"
echo "============================"
echo ""

# Configuration
STORAGE_BOX_HOST="u483283-sub2.your-storagebox.de"
STORAGE_BOX_USER="u483283-sub2"
MOUNT_POINT="/mnt/storage-box"

# Function to test connection methods
test_connections() {
    echo -e "${BLUE}Testing Storage Box connections...${NC}"
    
    # Test SSH connection
    echo -n "Testing SSH connection... "
    if sshpass -p "$1" ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 \
        ${STORAGE_BOX_USER}@${STORAGE_BOX_HOST} "echo connected" 2>/dev/null; then
        echo -e "${GREEN}✓ SSH works${NC}"
        SSH_WORKS=true
    else
        echo -e "${RED}✗ SSH failed${NC}"
        SSH_WORKS=false
    fi
    
    # Test SMB/CIFS connection
    echo -n "Testing SMB/CIFS connection... "
    mkdir -p /tmp/test-mount
    if mount -t cifs //${STORAGE_BOX_HOST}/${STORAGE_BOX_USER} /tmp/test-mount \
        -o user=${STORAGE_BOX_USER},pass="$1",vers=3.0 2>/dev/null; then
        echo -e "${GREEN}✓ SMB/CIFS works${NC}"
        umount /tmp/test-mount
        SMB_WORKS=true
    else
        echo -e "${RED}✗ SMB/CIFS failed${NC}"
        SMB_WORKS=false
    fi
    rmdir /tmp/test-mount 2>/dev/null || true
}

# Function to setup SSHFS mount
setup_sshfs() {
    echo -e "${BLUE}Setting up SSHFS mount...${NC}"
    
    # Install dependencies
    apt-get update && apt-get install -y sshfs sshpass
    
    # Create mount point
    mkdir -p ${MOUNT_POINT}
    
    # Add to fstab for persistent mount
    grep -v "${STORAGE_BOX_HOST}" /etc/fstab > /etc/fstab.tmp || true
    echo "sshfs#${STORAGE_BOX_USER}@${STORAGE_BOX_HOST}:/ ${MOUNT_POINT} fuse _netdev,allow_other,reconnect,ServerAliveInterval=15,IdentityFile=/root/.ssh/storagebox_key 0 0" >> /etc/fstab.tmp
    mv /etc/fstab.tmp /etc/fstab
    
    # Create SSH key for passwordless access
    ssh-keygen -t rsa -b 4096 -f /root/.ssh/storagebox_key -N "" -q
    
    echo -e "${YELLOW}Please add this SSH key to your Storage Box:${NC}"
    cat /root/.ssh/storagebox_key.pub
    echo ""
    echo "You can add it in Hetzner Robot at:"
    echo "https://robot.hetzner.com/storage"
    echo ""
    
    # Mount using password for now
    echo "Mounting with password authentication..."
    sshpass -p "$1" sshfs -o allow_other,reconnect,ServerAliveInterval=15 \
        ${STORAGE_BOX_USER}@${STORAGE_BOX_HOST}:/ ${MOUNT_POINT}
    
    if mountpoint -q ${MOUNT_POINT}; then
        echo -e "${GREEN}✓ Storage Box mounted at ${MOUNT_POINT}${NC}"
        df -h ${MOUNT_POINT}
    else
        echo -e "${RED}✗ Failed to mount Storage Box${NC}"
        return 1
    fi
}

# Function to setup SMB/CIFS mount
setup_smb() {
    echo -e "${BLUE}Setting up SMB/CIFS mount...${NC}"
    
    # Install dependencies
    apt-get update && apt-get install -y cifs-utils
    
    # Create mount point
    mkdir -p ${MOUNT_POINT}
    
    # Create credentials file
    cat > /root/.smbcredentials <<EOF
username=${STORAGE_BOX_USER}
password=$1
domain=WORKGROUP
EOF
    chmod 600 /root/.smbcredentials
    
    # Add to fstab for persistent mount
    grep -v "${STORAGE_BOX_HOST}" /etc/fstab > /etc/fstab.tmp || true
    echo "//${STORAGE_BOX_HOST}/${STORAGE_BOX_USER} ${MOUNT_POINT} cifs credentials=/root/.smbcredentials,iocharset=utf8,rw,vers=3.0,_netdev,uid=0,gid=0,file_mode=0660,dir_mode=0770 0 0" >> /etc/fstab.tmp
    mv /etc/fstab.tmp /etc/fstab
    
    # Mount
    mount ${MOUNT_POINT}
    
    if mountpoint -q ${MOUNT_POINT}; then
        echo -e "${GREEN}✓ Storage Box mounted at ${MOUNT_POINT}${NC}"
        df -h ${MOUNT_POINT}
    else
        echo -e "${RED}✗ Failed to mount Storage Box${NC}"
        return 1
    fi
}

# Function to setup rclone (alternative method)
setup_rclone() {
    echo -e "${BLUE}Setting up rclone...${NC}"
    
    # Install rclone
    curl https://rclone.org/install.sh | bash
    
    # Configure rclone
    cat > /root/.config/rclone/rclone.conf <<EOF
[storagebox]
type = sftp
host = ${STORAGE_BOX_HOST}
user = ${STORAGE_BOX_USER}
pass = $(echo "$1" | rclone obscure -)
EOF
    
    echo -e "${GREEN}✓ Rclone configured${NC}"
    echo "You can now use: rclone ls storagebox:/"
}

# Main execution
main() {
    # Check if running as root
    if [ "$EUID" -ne 0 ]; then 
        echo -e "${RED}Please run as root${NC}"
        exit 1
    fi
    
    # Get password
    if [ -z "$1" ]; then
        echo -n "Enter Storage Box password: "
        read -s STORAGE_BOX_PASS
        echo ""
    else
        STORAGE_BOX_PASS="$1"
    fi
    
    # Test connections
    test_connections "$STORAGE_BOX_PASS"
    
    # Choose best method
    if [ "$SSH_WORKS" = true ]; then
        echo -e "${GREEN}Using SSHFS (recommended)${NC}"
        setup_sshfs "$STORAGE_BOX_PASS"
        setup_rclone "$STORAGE_BOX_PASS"
    elif [ "$SMB_WORKS" = true ]; then
        echo -e "${YELLOW}Using SMB/CIFS (fallback)${NC}"
        setup_smb "$STORAGE_BOX_PASS"
    else
        echo -e "${RED}No working connection method found!${NC}"
        echo "Please check:"
        echo "1. Storage Box credentials are correct"
        echo "2. SSH/SMB is enabled in Hetzner Robot"
        echo "3. Network connectivity to Storage Box"
        exit 1
    fi
    
    # Store credentials in Vault
    echo -e "${BLUE}Storing credentials in Vault...${NC}"
    docker exec -e VAULT_TOKEN=root-token vault-cloudya-final vault kv put secret/development/storage-box \
        host=${STORAGE_BOX_HOST} \
        username=${STORAGE_BOX_USER} \
        password="${STORAGE_BOX_PASS}" \
        mount_point=${MOUNT_POINT}
    
    echo ""
    echo -e "${GREEN}✅ Storage Box setup complete!${NC}"
    echo "Mount point: ${MOUNT_POINT}"
    echo ""
    echo "Next steps:"
    echo "1. Add SSH key to Storage Box in Hetzner Robot (if using SSHFS)"
    echo "2. Run OwnCloud migration: make migrate-owncloud"
}

# Handle password as argument or prompt
main "$1"