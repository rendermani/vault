#!/bin/bash
# Setup Nomad host volumes for Vault deployment
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
VOLUME_PATH="/opt/nomad/volumes"
ENVIRONMENT="all"
DRY_RUN=false
CLEANUP=false

# Usage function
usage() {
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  -e, --environment ENV    Environment to setup (develop|staging|production|all) [default: all]"
    echo "  -p, --path PATH          Base path for volumes [default: /opt/nomad/volumes]"
    echo "  -d, --dry-run           Show what would be created without executing"
    echo "  -c, --cleanup           Remove existing volumes (DANGEROUS)"
    echo "  -h, --help              Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 --environment develop"
    echo "  $0 --environment all --path /custom/path"
    echo "  $0 --dry-run"
    echo ""
}

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -e|--environment)
            ENVIRONMENT="$2"
            shift 2
            ;;
        -p|--path)
            VOLUME_PATH="$2"
            shift 2
            ;;
        -d|--dry-run)
            DRY_RUN=true
            shift
            ;;
        -c|--cleanup)
            CLEANUP=true
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            usage
            exit 1
            ;;
    esac
done

# Validate environment
case $ENVIRONMENT in
    develop|staging|production|all)
        ;;
    *)
        log_error "Invalid environment: $ENVIRONMENT"
        log_error "Valid environments: develop, staging, production, all"
        exit 1
        ;;
esac

log_info "Setting up Nomad volumes for Vault"
log_info "Environment: $ENVIRONMENT"
log_info "Volume path: $VOLUME_PATH"
log_info "Dry run: $DRY_RUN"

# Check if running as root
check_permissions() {
    if [[ $EUID -ne 0 ]] && ! $DRY_RUN; then
        log_error "This script must be run as root to create directories and set permissions"
        log_error "Try: sudo $0 $*"
        exit 1
    fi
}

# Create volume directory structure for an environment
setup_environment_volumes() {
    local env=$1
    log_info "Setting up volumes for $env environment..."
    
    # Define volume names for the environment
    local volumes=(
        "vault-$env-data"
        "vault-$env-config" 
        "vault-$env-logs"
    )
    
    # Add additional volumes for staging and production
    if [ "$env" != "develop" ]; then
        volumes+=("vault-$env-certs")
    fi
    
    if [ "$env" = "production" ]; then
        volumes+=("vault-$env-backup")
    fi
    
    for volume in "${volumes[@]}"; do
        local volume_dir="$VOLUME_PATH/$volume"
        
        if $CLEANUP && [ -d "$volume_dir" ]; then
            log_warning "Removing existing volume: $volume_dir"
            if ! $DRY_RUN; then
                rm -rf "$volume_dir"
            fi
        fi
        
        log_info "Creating volume directory: $volume_dir"
        
        if ! $DRY_RUN; then
            mkdir -p "$volume_dir"
            
            # Set appropriate permissions based on volume type
            case $volume in
                *-data)
                    # Vault data needs strict permissions
                    chmod 700 "$volume_dir"
                    log_info "Set permissions 700 for data volume: $volume"
                    ;;
                *-config)
                    # Config can be more permissive
                    chmod 755 "$volume_dir"
                    log_info "Set permissions 755 for config volume: $volume"
                    ;;
                *-logs)
                    # Logs need write access
                    chmod 755 "$volume_dir"
                    log_info "Set permissions 755 for logs volume: $volume"
                    ;;
                *-certs)
                    # Certificates need strict permissions
                    chmod 600 "$volume_dir"
                    log_info "Set permissions 600 for certs volume: $volume"
                    ;;
                *-backup)
                    # Backups need strict permissions
                    chmod 700 "$volume_dir"
                    log_info "Set permissions 700 for backup volume: $volume"
                    ;;
            esac
            
            # Create vault user if it doesn't exist (for production)
            if [ "$env" = "production" ] && ! id vault >/dev/null 2>&1; then
                log_info "Creating vault user for production environment"
                useradd -r -s /bin/false -d "$VOLUME_PATH" vault
            fi
            
            # Set ownership for production
            if [ "$env" = "production" ] && id vault >/dev/null 2>&1; then
                chown vault:vault "$volume_dir"
                log_info "Set ownership vault:vault for: $volume"
            fi
            
            # Create subdirectories for data volumes
            if [[ $volume == *-data ]]; then
                mkdir -p "$volume_dir/core"
                mkdir -p "$volume_dir/sys"
                
                if [ "$env" = "production" ] && id vault >/dev/null 2>&1; then
                    chown vault:vault "$volume_dir/core" "$volume_dir/sys"
                fi
                
                log_info "Created subdirectories in: $volume"
            fi
        else
            log_info "[DRY-RUN] Would create: $volume_dir"
        fi
    done
    
    log_success "Completed volume setup for $env environment"
}

# Generate TLS certificates for staging and production
generate_certificates() {
    local env=$1
    local certs_dir="$VOLUME_PATH/vault-$env-certs"
    
    if [ "$env" = "develop" ]; then
        return 0  # No TLS for development
    fi
    
    log_info "Generating TLS certificates for $env environment..."
    
    if $DRY_RUN; then
        log_info "[DRY-RUN] Would generate certificates in: $certs_dir"
        return 0
    fi
    
    # Check if certificates already exist
    if [ -f "$certs_dir/vault-$env.crt" ]; then
        log_warning "Certificates already exist for $env environment"
        return 0
    fi
    
    # Ensure certs directory exists
    mkdir -p "$certs_dir"
    chmod 600 "$certs_dir"
    
    local domain
    case $env in
        staging)
            domain="vault-staging.cloudya.net"
            ;;
        production)
            domain="vault.cloudya.net"
            ;;
    esac
    
    # Generate private key
    openssl genrsa -out "$certs_dir/vault-$env.key" 2048
    chmod 600 "$certs_dir/vault-$env.key"
    
    # Generate certificate signing request
    openssl req -new -key "$certs_dir/vault-$env.key" \
        -out "$certs_dir/vault-$env.csr" \
        -subj "/C=US/ST=State/L=City/O=Cloudya/OU=Infrastructure/CN=$domain"
    
    # Generate self-signed certificate (replace with proper CA-signed cert in production)
    openssl x509 -req -days 365 \
        -in "$certs_dir/vault-$env.csr" \
        -signkey "$certs_dir/vault-$env.key" \
        -out "$certs_dir/vault-$env.crt" \
        -extensions v3_req \
        -extfile <(cat <<EOF
[v3_req]
keyUsage = keyEncipherment, dataEncipherment
extendedKeyUsage = serverAuth
subjectAltName = @alt_names

[alt_names]
DNS.1 = $domain
DNS.2 = localhost
IP.1 = 127.0.0.1
EOF
)
    
    chmod 644 "$certs_dir/vault-$env.crt"
    
    # Create CA certificate (self-signed for now)
    cp "$certs_dir/vault-$env.crt" "$certs_dir/vault-ca.pem"
    
    # Clean up CSR
    rm "$certs_dir/vault-$env.csr"
    
    # Set ownership for production
    if [ "$env" = "production" ] && id vault >/dev/null 2>&1; then
        chown vault:vault "$certs_dir"/*
    fi
    
    log_success "Generated TLS certificates for $env environment"
    log_warning "NOTE: Using self-signed certificates. Replace with CA-signed certificates for production!"
}

# Create Nomad volume configuration
create_nomad_volume_config() {
    local config_file="$PROJECT_ROOT/config/nomad-volumes.hcl"
    
    log_info "Creating Nomad volume configuration..."
    
    if $DRY_RUN; then
        log_info "[DRY-RUN] Would create volume configuration at: $config_file"
        return 0
    fi
    
    mkdir -p "$(dirname "$config_file")"
    
    cat > "$config_file" <<EOF
# Nomad Host Volume Configuration for Vault
# Add these volume configurations to your Nomad client configuration

client {
  host_volume "vault-develop-data" {
    path      = "$VOLUME_PATH/vault-develop-data"
    read_only = false
  }

  host_volume "vault-develop-config" {
    path      = "$VOLUME_PATH/vault-develop-config"
    read_only = false
  }

  host_volume "vault-develop-logs" {
    path      = "$VOLUME_PATH/vault-develop-logs"
    read_only = false
  }

  host_volume "vault-staging-data" {
    path      = "$VOLUME_PATH/vault-staging-data"
    read_only = false
  }

  host_volume "vault-staging-config" {
    path      = "$VOLUME_PATH/vault-staging-config"
    read_only = false
  }

  host_volume "vault-staging-logs" {
    path      = "$VOLUME_PATH/vault-staging-logs"
    read_only = false
  }

  host_volume "vault-staging-certs" {
    path      = "$VOLUME_PATH/vault-staging-certs"
    read_only = true
  }

  host_volume "vault-production-data" {
    path      = "$VOLUME_PATH/vault-production-data"
    read_only = false
  }

  host_volume "vault-production-config" {
    path      = "$VOLUME_PATH/vault-production-config"
    read_only = false
  }

  host_volume "vault-production-logs" {
    path      = "$VOLUME_PATH/vault-production-logs"
    read_only = false
  }

  host_volume "vault-production-certs" {
    path      = "$VOLUME_PATH/vault-production-certs"
    read_only = true
  }

  host_volume "vault-production-backup" {
    path      = "$VOLUME_PATH/vault-production-backup"
    read_only = false
  }
}
EOF
    
    log_success "Created Nomad volume configuration: $config_file"
    log_info "Add this configuration to your Nomad client config and restart the agent"
}

# Validate volume setup
validate_volumes() {
    log_info "Validating volume setup..."
    
    local envs=()
    if [ "$ENVIRONMENT" = "all" ]; then
        envs=("develop" "staging" "production")
    else
        envs=("$ENVIRONMENT")
    fi
    
    for env in "${envs[@]}"; do
        log_info "Validating $env environment volumes..."
        
        local volumes=(
            "vault-$env-data"
            "vault-$env-config"
            "vault-$env-logs"
        )
        
        if [ "$env" != "develop" ]; then
            volumes+=("vault-$env-certs")
        fi
        
        if [ "$env" = "production" ]; then
            volumes+=("vault-$env-backup")
        fi
        
        for volume in "${volumes[@]}"; do
            local volume_dir="$VOLUME_PATH/$volume"
            
            if [ -d "$volume_dir" ]; then
                log_success "✓ $volume exists"
                
                # Check permissions
                local perms=$(stat -c "%a" "$volume_dir" 2>/dev/null || stat -f "%A" "$volume_dir" 2>/dev/null)
                log_info "  Permissions: $perms"
                
                # Check ownership
                local owner=$(stat -c "%U:%G" "$volume_dir" 2>/dev/null || stat -f "%Su:%Sg" "$volume_dir" 2>/dev/null)
                log_info "  Owner: $owner"
            else
                log_error "✗ $volume missing"
            fi
        done
    done
}

# Main execution
main() {
    log_info "Nomad Volume Setup Script"
    
    check_permissions
    
    if $CLEANUP; then
        log_warning "CLEANUP MODE ENABLED - This will remove existing volumes!"
        if ! $DRY_RUN; then
            read -p "Are you sure you want to continue? [y/N]: " -n 1 -r
            echo ""
            if [[ ! $REPLY =~ ^[Yy]$ ]]; then
                log_info "Cleanup cancelled by user"
                exit 0
            fi
        fi
    fi
    
    # Setup volumes based on environment
    if [ "$ENVIRONMENT" = "all" ]; then
        setup_environment_volumes "develop"
        setup_environment_volumes "staging"
        setup_environment_volumes "production"
        
        # Generate certificates for staging and production
        generate_certificates "staging"
        generate_certificates "production"
    else
        setup_environment_volumes "$ENVIRONMENT"
        generate_certificates "$ENVIRONMENT"
    fi
    
    # Create Nomad configuration
    create_nomad_volume_config
    
    # Validate setup
    if ! $DRY_RUN; then
        validate_volumes
    fi
    
    log_success "Volume setup completed successfully!"
    
    echo ""
    log_info "Next steps:"
    log_info "1. Add the generated volume configuration to your Nomad client config"
    log_info "2. Restart your Nomad client agent"
    log_info "3. Run the bootstrap script to deploy Vault"
    
    if [ "$ENVIRONMENT" = "production" ] || [ "$ENVIRONMENT" = "all" ]; then
        echo ""
        log_warning "Production environment notes:"
        log_warning "- Replace self-signed certificates with CA-signed certificates"
        log_warning "- Ensure proper backup procedures are in place"
        log_warning "- Review and harden file permissions as needed"
        log_warning "- Consider using a dedicated vault user account"
    fi
}

# Execute main function
main "$@"