#!/bin/bash

# Storage Box Sync Script for OwnCloud Migration
# This script syncs OwnCloud data to Hetzner Storage Box

set -e

# Configuration
STORAGE_HOST="u483283.your-storagebox.de"
STORAGE_USER="u483283"
STORAGE_PASS="derZ!5UGVYxJ.#s"
STORAGE_PORT="23"
OLD_SERVER="old.cloudya.net"
OWNCLOUD_SOURCE="/var/lib/docker/volumes/owncloud_files/"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo "🔄 OwnCloud to Storage Box Sync"
echo "================================"
echo ""

# Function to check if we're unblocked
check_connection() {
    echo -e "${BLUE}Checking connection to storage box...${NC}"
    if nc -zv -w 5 $STORAGE_HOST $STORAGE_PORT 2>&1 | grep -q "succeeded\|open"; then
        echo -e "${GREEN}✓ Port $STORAGE_PORT is open${NC}"
        return 0
    else
        echo -e "${RED}✗ Port $STORAGE_PORT is blocked or closed${NC}"
        return 1
    fi
}

# Function to create owncloud directory
create_directory() {
    echo -e "${BLUE}Creating owncloud directory on storage box...${NC}"
    expect -c "
        spawn ssh -p $STORAGE_PORT $STORAGE_USER@$STORAGE_HOST
        expect \"password:\"
        send \"$STORAGE_PASS\r\"
        expect \">\"
        send \"mkdir -p owncloud\r\"
        expect \">\"
        send \"ls -la\r\"
        expect \">\"
        send \"exit\r\"
        expect eof
    " 2>&1 | grep -E "(owncloud|mkdir)" || true
    echo -e "${GREEN}✓ Directory prepared${NC}"
}

# Function to sync data using rsync
sync_with_rsync() {
    echo -e "${BLUE}Starting rsync from old server to storage box...${NC}"
    echo -e "${YELLOW}This will take several hours for 822GB!${NC}"
    
    # Create rsync command that runs on old server
    ssh root@$OLD_SERVER "
        export SSHPASS='$STORAGE_PASS'
        sshpass -e rsync -avz --progress --stats \
            -e 'ssh -p $STORAGE_PORT' \
            $OWNCLOUD_SOURCE \
            $STORAGE_USER@$STORAGE_HOST:/home/owncloud/
    "
}

# Function to sync using scp (fallback)
sync_with_scp() {
    echo -e "${BLUE}Using SCP as fallback method...${NC}"
    
    # First create a tar archive on old server
    ssh root@$OLD_SERVER "
        cd /var/lib/docker/volumes/
        tar czf /tmp/owncloud_files.tar.gz owncloud_files/
        ls -lh /tmp/owncloud_files.tar.gz
    "
    
    # Then copy to storage box
    ssh root@$OLD_SERVER "
        export SSHPASS='$STORAGE_PASS'
        sshpass -e scp -P $STORAGE_PORT \
            /tmp/owncloud_files.tar.gz \
            $STORAGE_USER@$STORAGE_HOST:/home/owncloud/
    "
}

# Function to mount storage box locally
mount_storage() {
    echo -e "${BLUE}Mounting storage box locally...${NC}"
    
    mkdir -p /mnt/storage-box
    
    # Try SSHFS
    if command -v sshfs &> /dev/null; then
        echo "$STORAGE_PASS" | sshfs -o password_stdin,allow_other,reconnect,ServerAliveInterval=15,port=$STORAGE_PORT \
            $STORAGE_USER@$STORAGE_HOST:/home /mnt/storage-box
        
        if mountpoint -q /mnt/storage-box; then
            echo -e "${GREEN}✓ Mounted at /mnt/storage-box${NC}"
            df -h /mnt/storage-box
            return 0
        fi
    fi
    
    # Try CIFS/SMB
    mount -t cifs //$STORAGE_HOST/backup /mnt/storage-box \
        -o username=$STORAGE_USER,password="$STORAGE_PASS",vers=3.0
    
    if mountpoint -q /mnt/storage-box; then
        echo -e "${GREEN}✓ Mounted via SMB at /mnt/storage-box${NC}"
        df -h /mnt/storage-box
        return 0
    fi
    
    echo -e "${RED}✗ Failed to mount storage box${NC}"
    return 1
}

# Main execution
main() {
    echo "Waiting for storage box to be accessible..."
    
    # Wait until unblocked (check every minute)
    while ! check_connection; do
        echo -e "${YELLOW}Waiting 60 seconds before retry...${NC}"
        sleep 60
    done
    
    echo -e "${GREEN}Storage box is accessible!${NC}"
    
    # Create directory
    create_directory
    
    # Try to mount locally
    if mount_storage; then
        echo "Using local mount for transfer"
        # Direct copy from old server
        rsync -avzP root@$OLD_SERVER:$OWNCLOUD_SOURCE /mnt/storage-box/owncloud/
    else
        echo "Using remote sync"
        sync_with_rsync
    fi
    
    echo -e "${GREEN}✅ Sync complete!${NC}"
}

# Handle command line arguments
case "$1" in
    check)
        check_connection
        ;;
    mount)
        mount_storage
        ;;
    sync)
        sync_with_rsync
        ;;
    *)
        main
        ;;
esac