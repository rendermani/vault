#!/bin/bash
set -e

# Validation script for Nomad job files
# Checks job syntax and configuration before deployment

echo "Validating Nomad job files..."

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
JOBS_DIR="$(dirname "$SCRIPT_DIR")/jobs"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    local status=$1
    local message=$2
    case $status in
        "OK")
            echo -e "${GREEN}✓${NC} $message"
            ;;
        "WARNING")
            echo -e "${YELLOW}⚠${NC} $message"
            ;;
        "ERROR")
            echo -e "${RED}✗${NC} $message"
            ;;
        "INFO")
            echo -e "${YELLOW}ℹ${NC} $message"
            ;;
    esac
}

# Check if nomad CLI is available
if ! command -v nomad &> /dev/null; then
    print_status "ERROR" "Nomad CLI not found. Please install Nomad."
    exit 1
fi

print_status "INFO" "Found Nomad CLI: $(nomad version | head -1)"

# Validate job files
jobs=(
    "vault-production.nomad"
    "traefik-production.nomad"
)

validation_passed=true

for job in "${jobs[@]}"; do
    job_file="$JOBS_DIR/$job"
    
    if [ ! -f "$job_file" ]; then
        print_status "ERROR" "Job file not found: $job_file"
        validation_passed=false
        continue
    fi
    
    print_status "INFO" "Validating $job..."
    
    # Validate job syntax
    if nomad job validate "$job_file" &>/dev/null; then
        print_status "OK" "$job syntax is valid"
    else
        print_status "ERROR" "$job syntax validation failed"
        echo "Error details:"
        nomad job validate "$job_file" 2>&1 | sed 's/^/  /'
        validation_passed=false
        continue
    fi
    
    # Check for required configurations
    case $job in
        "vault-production.nomad")
            # Check Vault-specific configurations
            if grep -q "vault.crt" "$job_file"; then
                print_status "OK" "Vault TLS configuration found"
            else
                print_status "WARNING" "Vault TLS configuration may be missing"
            fi
            
            if grep -q "host_volume" "$job_file"; then
                print_status "OK" "Vault volume mounts configured"
            else
                print_status "ERROR" "Vault volume mounts missing"
                validation_passed=false
            fi
            
            if grep -q "service.*vault" "$job_file"; then
                print_status "OK" "Vault service registration configured"
            else
                print_status "ERROR" "Vault service registration missing"
                validation_passed=false
            fi
            ;;
            
        "traefik-production.nomad")
            # Check Traefik-specific configurations
            if grep -q "letsencrypt" "$job_file"; then
                print_status "OK" "Traefik Let's Encrypt configuration found"
            else
                print_status "WARNING" "Let's Encrypt configuration may be missing"
            fi
            
            if grep -q "vault.cloudya.net" "$job_file"; then
                print_status "OK" "Vault routing configuration found"
            else
                print_status "ERROR" "Vault routing configuration missing"
                validation_passed=false
            fi
            
            if grep -q "consul" "$job_file"; then
                print_status "OK" "Consul service discovery configured"
            else
                print_status "WARNING" "Consul service discovery may be missing"
            fi
            ;;
    esac
done

# Check for required directories
print_status "INFO" "Checking host volume directories..."

volume_dirs=(
    "/opt/nomad/volumes/vault-data"
    "/opt/nomad/volumes/vault-config"
    "/opt/nomad/volumes/vault-logs"
    "/opt/nomad/volumes/vault-certs"
    "/opt/nomad/volumes/traefik-certs"
    "/opt/nomad/volumes/traefik-config"
)

for dir in "${volume_dirs[@]}"; do
    if [ -d "$dir" ]; then
        print_status "OK" "Directory exists: $dir"
    else
        print_status "WARNING" "Directory missing: $dir (run setup-host-volumes.sh)"
    fi
done

# Check for SSL certificates
cert_files=(
    "/opt/nomad/volumes/vault-certs/vault.crt"
    "/opt/nomad/volumes/vault-certs/vault.key"
)

for cert in "${cert_files[@]}"; do
    if [ -f "$cert" ]; then
        print_status "OK" "Certificate found: $(basename "$cert")"
        
        # Validate certificate if openssl is available
        if command -v openssl &> /dev/null; then
            if [[ "$cert" == *.crt ]]; then
                if openssl x509 -in "$cert" -noout -text &>/dev/null; then
                    expiry=$(openssl x509 -in "$cert" -noout -enddate | cut -d= -f2)
                    print_status "OK" "Certificate is valid (expires: $expiry)"
                else
                    print_status "ERROR" "Certificate validation failed: $(basename "$cert")"
                    validation_passed=false
                fi
            fi
        fi
    else
        print_status "WARNING" "Certificate missing: $(basename "$cert")"
    fi
done

# Check Nomad connectivity
print_status "INFO" "Checking Nomad connectivity..."

if nomad node status &>/dev/null; then
    print_status "OK" "Nomad cluster is accessible"
    node_count=$(nomad node status | grep -c "ready")
    print_status "INFO" "Found $node_count ready nodes"
else
    print_status "WARNING" "Cannot connect to Nomad cluster"
fi

# Check Consul connectivity
if command -v consul &> /dev/null; then
    print_status "INFO" "Checking Consul connectivity..."
    if consul members &>/dev/null; then
        print_status "OK" "Consul cluster is accessible"
    else
        print_status "WARNING" "Cannot connect to Consul cluster"
    fi
else
    print_status "WARNING" "Consul CLI not found"
fi

# Summary
echo ""
echo "=============================================="
if [ "$validation_passed" = true ]; then
    print_status "OK" "All validations passed! Jobs are ready for deployment."
    echo ""
    echo "Next steps:"
    echo "1. Ensure all host volumes are properly set up"
    echo "2. Install SSL certificates for Vault"
    echo "3. Deploy Traefik: nomad job run traefik-production.nomad"
    echo "4. Deploy Vault: nomad job run vault-production.nomad"
    exit 0
else
    print_status "ERROR" "Validation failed! Please fix the issues above before deployment."
    exit 1
fi