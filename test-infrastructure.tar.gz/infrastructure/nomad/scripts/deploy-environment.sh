#!/bin/bash
# Environment-specific deployment script for Vault
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
ENVIRONMENT=""
ACTION="deploy"
AUTO_APPROVE=false
VAULT_TOKEN=""
SKIP_VOLUMES=false
SKIP_HEALTH_CHECK=false

# Usage function
usage() {
    echo "Usage: $0 --environment ENV [OPTIONS]"
    echo ""
    echo "Required:"
    echo "  -e, --environment ENV    Environment to deploy (develop|staging|production)"
    echo ""
    echo "Options:"
    echo "  -a, --action ACTION      Action to perform (deploy|destroy|restart|status) [default: deploy]"
    echo "  -t, --token TOKEN        Vault token for authentication"
    echo "  -y, --yes               Auto-approve actions without prompts"
    echo "  --skip-volumes          Skip volume setup (assumes already configured)"
    echo "  --skip-health-check     Skip post-deployment health checks"
    echo "  -h, --help              Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 --environment develop"
    echo "  $0 --environment staging --action deploy --yes"
    echo "  $0 --environment production --action status"
    echo "  $0 --environment develop --action destroy"
    echo ""
}

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -e|--environment)
            ENVIRONMENT="$2"
            shift 2
            ;;
        -a|--action)
            ACTION="$2"
            shift 2
            ;;
        -t|--token)
            VAULT_TOKEN="$2"
            shift 2
            ;;
        -y|--yes)
            AUTO_APPROVE=true
            shift
            ;;
        --skip-volumes)
            SKIP_VOLUMES=true
            shift
            ;;
        --skip-health-check)
            SKIP_HEALTH_CHECK=true
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            usage
            exit 1
            ;;
    esac
done

# Validate required parameters
if [ -z "$ENVIRONMENT" ]; then
    log_error "Environment is required"
    usage
    exit 1
fi

# Validate environment
case $ENVIRONMENT in
    develop|staging|production)
        ;;
    *)
        log_error "Invalid environment: $ENVIRONMENT"
        log_error "Valid environments: develop, staging, production"
        exit 1
        ;;
esac

# Validate action
case $ACTION in
    deploy|destroy|restart|status)
        ;;
    *)
        log_error "Invalid action: $ACTION"
        log_error "Valid actions: deploy, destroy, restart, status"
        exit 1
        ;;
esac

log_info "Vault Deployment Script"
log_info "Environment: $ENVIRONMENT"
log_info "Action: $ACTION"

# Job file path
JOB_FILE="$PROJECT_ROOT/jobs/$ENVIRONMENT/vault.nomad"
JOB_NAME="vault-$ENVIRONMENT"

# Check prerequisites
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check if Nomad is available
    if ! command -v nomad &> /dev/null; then
        log_error "Nomad CLI not found. Please install Nomad."
        exit 1
    fi
    
    # Check if we can connect to Nomad
    if ! nomad node status &> /dev/null; then
        log_error "Cannot connect to Nomad cluster. Is Nomad agent running?"
        exit 1
    fi
    
    # Check if job file exists for deploy action
    if [ "$ACTION" = "deploy" ] && [ ! -f "$JOB_FILE" ]; then
        log_error "Job file not found: $JOB_FILE"
        exit 1
    fi
    
    log_success "Prerequisites check passed"
}

# Setup volumes if needed
setup_volumes() {
    if $SKIP_VOLUMES; then
        log_info "Skipping volume setup as requested"
        return 0
    fi
    
    log_info "Setting up volumes for $ENVIRONMENT environment..."
    
    local volume_script="$SCRIPT_DIR/setup-nomad-volumes.sh"
    
    if [ ! -f "$volume_script" ]; then
        log_error "Volume setup script not found: $volume_script"
        exit 1
    fi
    
    # Run volume setup script
    if ! bash "$volume_script" --environment "$ENVIRONMENT"; then
        log_error "Volume setup failed"
        exit 1
    fi
    
    log_success "Volume setup completed"
}

# Deploy action
deploy_vault() {
    log_info "Deploying Vault to $ENVIRONMENT environment..."
    
    # Setup volumes first
    setup_volumes
    
    # Validate job
    log_info "Validating job configuration..."
    if ! nomad job validate "$JOB_FILE"; then
        log_error "Job validation failed"
        exit 1
    fi
    
    # Plan deployment
    log_info "Planning deployment..."
    if ! nomad job plan "$JOB_FILE"; then
        log_error "Deployment planning failed"
        exit 1
    fi
    
    # Confirm deployment
    if ! $AUTO_APPROVE; then
        echo ""
        log_warning "This will deploy Vault to the $ENVIRONMENT environment."
        read -p "Are you sure you want to continue? [y/N]: " -n 1 -r
        echo ""
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            log_info "Deployment cancelled by user"
            exit 0
        fi
    fi
    
    # Deploy
    log_info "Deploying job..."
    if ! nomad job run "$JOB_FILE"; then
        log_error "Deployment failed"
        exit 1
    fi
    
    log_success "Vault deployed successfully"
    
    # Wait for deployment and health check
    if ! $SKIP_HEALTH_CHECK; then
        wait_for_healthy_deployment
        perform_health_checks
    fi
}

# Destroy action
destroy_vault() {
    log_warning "Destroying Vault deployment in $ENVIRONMENT environment..."
    
    # Check if job exists
    if ! nomad job status "$JOB_NAME" &> /dev/null; then
        log_warning "Job $JOB_NAME does not exist"
        return 0
    fi
    
    # Confirm destruction
    if ! $AUTO_APPROVE; then
        echo ""
        log_error "⚠️  DANGER: This will completely destroy the Vault deployment!"
        log_error "⚠️  All data will be lost unless you have backups!"
        echo ""
        read -p "Type 'YES' to confirm destruction: " -r
        if [ "$REPLY" != "YES" ]; then
            log_info "Destruction cancelled by user"
            exit 0
        fi
    fi
    
    # Stop and purge job
    log_info "Stopping job $JOB_NAME..."
    if ! nomad job stop "$JOB_NAME"; then
        log_error "Failed to stop job"
        exit 1
    fi
    
    # Wait for job to stop
    log_info "Waiting for job to stop..."
    sleep 10
    
    # Purge job history
    log_info "Purging job history..."
    if ! nomad job stop -purge "$JOB_NAME"; then
        log_warning "Failed to purge job history (this is often normal)"
    fi
    
    log_success "Vault deployment destroyed"
}

# Restart action
restart_vault() {
    log_info "Restarting Vault deployment in $ENVIRONMENT environment..."
    
    # Check if job exists
    if ! nomad job status "$JOB_NAME" &> /dev/null; then
        log_error "Job $JOB_NAME does not exist. Cannot restart."
        exit 1
    fi
    
    # Confirm restart
    if ! $AUTO_APPROVE; then
        echo ""
        log_warning "This will restart the Vault deployment."
        read -p "Are you sure you want to continue? [y/N]: " -n 1 -r
        echo ""
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            log_info "Restart cancelled by user"
            exit 0
        fi
    fi
    
    # Restart by redeploying
    log_info "Redeploying job for restart..."
    if ! nomad job run "$JOB_FILE"; then
        log_error "Restart failed"
        exit 1
    fi
    
    log_success "Vault restarted successfully"
    
    # Wait for deployment and health check
    if ! $SKIP_HEALTH_CHECK; then
        wait_for_healthy_deployment
        perform_health_checks
    fi
}

# Status action
show_status() {
    log_info "Checking Vault deployment status for $ENVIRONMENT environment..."
    
    # Check if job exists
    if ! nomad job status "$JOB_NAME" &> /dev/null; then
        log_warning "Job $JOB_NAME does not exist"
        return 0
    fi
    
    # Show job status
    echo ""
    log_info "=== Nomad Job Status ==="
    nomad job status "$JOB_NAME"
    
    # Show allocations
    echo ""
    log_info "=== Allocations ==="
    nomad job allocs "$JOB_NAME"
    
    # Show service health
    echo ""
    log_info "=== Service Registration ==="
    if command -v consul &> /dev/null; then
        consul catalog services | grep vault || log_info "No Vault services found in Consul"
    else
        log_info "Consul CLI not available - skipping service check"
    fi
    
    # Vault specific status
    echo ""
    log_info "=== Vault Status ==="
    if command -v vault &> /dev/null; then
        local vault_addr
        case $ENVIRONMENT in
            develop)
                vault_addr="http://localhost:8200"
                ;;
            staging)
                vault_addr="https://localhost:8210"
                export VAULT_SKIP_VERIFY=true
                ;;
            production)
                vault_addr="https://localhost:8220"
                ;;
        esac
        
        export VAULT_ADDR="$vault_addr"
        
        if [ -n "$VAULT_TOKEN" ]; then
            export VAULT_TOKEN="$VAULT_TOKEN"
        fi
        
        log_info "Checking Vault at: $vault_addr"
        
        if vault status; then
            log_success "Vault is accessible"
        else
            log_warning "Vault status check failed (may be expected if not initialized)"
        fi
    else
        log_info "Vault CLI not available - skipping Vault status check"
    fi
}

# Wait for healthy deployment
wait_for_healthy_deployment() {
    log_info "Waiting for deployment to be healthy..."
    
    local timeout=600  # 10 minutes
    local interval=10
    local elapsed=0
    
    while [ $elapsed -lt $timeout ]; do
        local status=$(nomad job status "$JOB_NAME" 2>/dev/null | grep "Status" | awk '{print $3}' || echo "unknown")
        
        if [ "$status" = "running" ]; then
            # Check if all allocations are healthy
            local running_allocs=$(nomad job status "$JOB_NAME" 2>/dev/null | grep -c "running" || echo "0")
            
            if [ "$running_allocs" -gt 0 ]; then
                log_success "Deployment is healthy"
                return 0
            fi
        fi
        
        log_info "Deployment status: $status (waiting... ${elapsed}s/${timeout}s)"
        sleep $interval
        elapsed=$((elapsed + interval))
    done
    
    log_error "Deployment did not become healthy within $timeout seconds"
    exit 1
}

# Perform health checks
perform_health_checks() {
    log_info "Performing health checks..."
    
    # Get vault endpoint
    local vault_addr
    case $ENVIRONMENT in
        develop)
            vault_addr="http://localhost:8200"
            ;;
        staging)
            vault_addr="https://localhost:8210"
            export VAULT_SKIP_VERIFY=true
            ;;
        production)
            vault_addr="https://localhost:8220"
            ;;
    esac
    
    # Test HTTP connectivity
    log_info "Testing HTTP connectivity to Vault..."
    
    local timeout=120
    local interval=5
    local elapsed=0
    
    while [ $elapsed -lt $timeout ]; do
        if [ "$ENVIRONMENT" = "develop" ]; then
            if curl -s -f "$vault_addr/v1/sys/health" > /dev/null; then
                log_success "HTTP health check passed"
                break
            fi
        else
            if curl -s -f -k "$vault_addr/v1/sys/health" > /dev/null; then
                log_success "HTTPS health check passed"
                break
            fi
        fi
        
        log_info "Waiting for Vault HTTP endpoint... ${elapsed}s/${timeout}s"
        sleep $interval
        elapsed=$((elapsed + interval))
    done
    
    if [ $elapsed -ge $timeout ]; then
        log_warning "HTTP health check timed out"
    fi
    
    # Vault CLI health check if available
    if command -v vault &> /dev/null; then
        export VAULT_ADDR="$vault_addr"
        
        log_info "Testing Vault CLI connectivity..."
        
        if vault status &> /dev/null; then
            log_success "Vault CLI health check passed"
        else
            log_warning "Vault CLI health check failed (may be expected if not initialized)"
        fi
    fi
    
    log_success "Health checks completed"
}

# Display post-deployment information
show_post_deployment_info() {
    echo ""
    log_info "=== Post-Deployment Information ==="
    
    case $ENVIRONMENT in
        develop)
            log_info "Vault Development Environment Deployed"
            log_info "- Endpoint: http://localhost:8200"
            log_info "- UI: http://localhost:8200/ui"
            log_info "- Auto-initialization: Enabled"
            log_info "- TLS: Disabled (development only)"
            ;;
        staging)
            log_info "Vault Staging Environment Deployed"
            log_info "- Endpoint: https://localhost:8210"
            log_info "- UI: https://localhost:8210/ui (accept self-signed cert)"
            log_info "- Manual initialization required"
            log_info "- TLS: Self-signed certificates"
            ;;
        production)
            log_info "Vault Production Environment Deployed"
            log_info "- Endpoint: https://localhost:8220"
            log_info "- UI: https://localhost:8220/ui"
            log_info "- Manual initialization required"
            log_info "- TLS: Production certificates required"
            ;;
    esac
    
    echo ""
    log_info "Next Steps:"
    
    case $ENVIRONMENT in
        develop)
            log_info "1. Wait for auto-initialization to complete"
            log_info "2. Check logs: nomad alloc logs \$(nomad job allocs vault-develop -json | jq -r '.[0].ID') vault"
            log_info "3. Login: export VAULT_ADDR=http://localhost:8200 && vault auth"
            ;;
        staging)
            log_info "1. Initialize Vault manually"
            log_info "2. Configure staging policies and auth methods"
            log_info "3. Test application integration"
            ;;
        production)
            log_info "1. ⚠️  SECURE RECOVERY KEYS IMMEDIATELY"
            log_info "2. Initialize Vault with proper ceremony"
            log_info "3. Configure production policies"
            log_info "4. Set up monitoring and backups"
            log_info "5. Complete security audit"
            ;;
    esac
    
    echo ""
    log_info "Useful Commands:"
    log_info "- Check status: nomad job status $JOB_NAME"
    log_info "- View logs: nomad alloc logs \$(nomad job allocs $JOB_NAME -json | jq -r '.[0].ID') vault"
    log_info "- Restart: $0 --environment $ENVIRONMENT --action restart"
    log_info "- Destroy: $0 --environment $ENVIRONMENT --action destroy"
}

# Main execution
main() {
    check_prerequisites
    
    case $ACTION in
        deploy)
            deploy_vault
            show_post_deployment_info
            ;;
        destroy)
            destroy_vault
            ;;
        restart)
            restart_vault
            show_post_deployment_info
            ;;
        status)
            show_status
            ;;
        *)
            log_error "Unknown action: $ACTION"
            exit 1
            ;;
    esac
    
    log_success "Operation completed successfully!"
}

# Execute main function
main "$@"