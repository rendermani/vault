#!/bin/bash

# Helper script to update Traefik password from Vault
# Usage: ./update-traefik-auth.sh [vault-token]

set -e

echo "🔄 Updating Traefik authentication from Vault..."

# Use provided token or prompt for it
if [ "$1" ]; then
    VAULT_TOKEN="$1"
elif [ "$VAULT_TOKEN" ]; then
    echo "Using VAULT_TOKEN environment variable"
else
    echo "Please provide Vault token as argument or set VAULT_TOKEN environment variable"
    echo "Usage: $0 <vault-token>"
    echo "Or: VAULT_TOKEN=<token> $0"
    exit 1
fi

echo "📡 Fetching credentials from Vault..."

# Get credentials from Vault
USERNAME=$(docker exec -e VAULT_ADDR=http://127.0.0.1:8200 -e VAULT_TOKEN="$VAULT_TOKEN" vault vault kv get -field=username secret/traefik/dashboard 2>/dev/null)
PASSWORD=$(docker exec -e VAULT_ADDR=http://127.0.0.1:8200 -e VAULT_TOKEN="$VAULT_TOKEN" vault vault kv get -field=password secret/traefik/dashboard 2>/dev/null)

if [ -z "$USERNAME" ] || [ -z "$PASSWORD" ]; then
    echo "❌ Failed to retrieve credentials from Vault. Check your token and ensure Vault is unsealed."
    exit 1
fi

echo "📝 Generating password hash for user: $USERNAME"
HASH=$(htpasswd -nb "$USERNAME" "$PASSWORD")

echo "💾 Updating authentication file..."
cat > traefik/config/dynamic/traefik-auth.yaml << EOF
http:
  middlewares:
    dashboard-auth:
      basicAuth:
        users:
          - "$HASH"
  
  routers:
    traefik-dashboard:
      rule: "Host(\`traefik.loc\`)"
      entryPoints:
        - websecure
      tls: true
      service: "api@internal"
      middlewares:
        - dashboard-auth

tls:
  certificates:
    - certFile: /certs/cert.pem
      keyFile: /certs/key.pem
      stores:
        - default
  stores:
    default:
      defaultCertificate:
        certFile: /certs/cert.pem
        keyFile: /certs/key.pem
EOF

echo "✅ Traefik authentication updated!"
echo "🔐 New credentials: $USERNAME / [password hidden]"
echo "🔄 Traefik will automatically reload the configuration within a few seconds."
