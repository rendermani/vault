#!/bin/bash
set -e

echo "Waiting for Vault to be ready..."
until curl -s http://vault:8200/v1/sys/health > /dev/null; do
  sleep 2
done

echo "Vault is ready, authenticating..."
export VAULT_ADDR=http://vault:8200

# Authenticate using token or other method
export VAULT_TOKEN="${VAULT_TOKEN}"

echo "Fetching Traefik dashboard credentials..."
PASSWORD_HASH=$(vault kv get -field=password_hash traefik/dashboard)

if [ -z "$PASSWORD_HASH" ]; then
  echo "Error: Could not retrieve password hash from Vault"
  exit 1
fi

# Write the htpasswd formatted credentials to the shared volume
echo "admin:$PASSWORD_HASH" > /shared/traefik-auth.txt

echo "Credentials written successfully"
