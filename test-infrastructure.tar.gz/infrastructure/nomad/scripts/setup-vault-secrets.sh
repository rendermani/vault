#!/bin/bash
# Script to setup Vault secrets for Cloudya

set -e

echo "Setting up Vault secrets for Cloudya..."

# Check if VAULT_TOKEN is set
if [ -z "$VAULT_TOKEN" ]; then
    echo "Error: VAULT_TOKEN environment variable is not set"
    echo "Please set VAULT_TOKEN and run this script again"
    exit 1
fi

export VAULT_ADDR="${VAULT_ADDR:-http://localhost:8200}"

echo "Using Vault at: $VAULT_ADDR"

# Enable KV secrets engine if not already enabled
echo "Enabling KV secrets engine..."
vault secrets enable -path=secret kv-v2 2>/dev/null || echo "KV engine already enabled"

# Generate a secure password hash for admin
PASSWORD_HASH=$(htpasswd -nb admin changeme123 | cut -d: -f2)

echo "Storing Traefik dashboard credentials..."
vault kv put secret/traefik/dashboard \
    username="admin" \
    password_hash="$PASSWORD_HASH"

echo "Storing OwnCloud admin credentials..."
vault kv put secret/owncloud/admin \
    username="admin" \
    password="secure-owncloud-password-$(date +%s)"

echo "Storing OwnCloud database credentials..."
vault kv put secret/owncloud/database \
    host="postgres" \
    username="owncloud" \
    password="secure-db-password-$(date +%s)" \
    database="owncloud"

echo ""
echo "✅ Vault secrets have been created successfully!"
echo ""
echo "📋 Summary:"
echo "  - Traefik dashboard: admin / changeme123"
echo "  - OwnCloud admin credentials stored"
echo "  - OwnCloud database credentials stored"
echo ""
echo "⚠️  Remember to:"
echo "  1. Change the default passwords"
echo "  2. Set up proper Vault authentication (AppRole)"
echo "  3. Configure proper Vault policies"
echo ""
