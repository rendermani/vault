#!/bin/bash
# Vault Health Monitoring Script for Nomad Deployments
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
ENVIRONMENT="all"
WATCH_MODE=false
WATCH_INTERVAL=30
OUTPUT_FORMAT="text"  # text, json, prometheus
ALERT_WEBHOOK=""
LOG_FILE=""
CONTINUOUS=false

# Health check results
HEALTH_STATUS=()
ALERTS=()

# Usage function
usage() {
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  -e, --environment ENV    Environment to monitor (develop|staging|production|all) [default: all]"
    echo "  -w, --watch             Enable watch mode (continuous monitoring)"
    echo "  -i, --interval SECONDS  Watch mode interval in seconds [default: 30]"
    echo "  -f, --format FORMAT     Output format (text|json|prometheus) [default: text]"
    echo "  -a, --alert-webhook URL Webhook URL for alerts"
    echo "  -l, --log-file FILE     Log output to file"
    echo "  -c, --continuous        Run continuously (same as --watch)"
    echo "  -h, --help              Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 --environment production"
    echo "  $0 --watch --interval 60"
    echo "  $0 --format json --log-file /var/log/vault-health.log"
    echo "  $0 --alert-webhook https://hooks.slack.com/your/webhook"
    echo ""
}

# Logging functions
log_info() {
    local msg="[$(date +'%Y-%m-%d %H:%M:%S')] [INFO] $1"
    echo -e "${BLUE}$msg${NC}"
    [ -n "$LOG_FILE" ] && echo "$msg" >> "$LOG_FILE"
}

log_success() {
    local msg="[$(date +'%Y-%m-%d %H:%M:%S')] [SUCCESS] $1"
    echo -e "${GREEN}$msg${NC}"
    [ -n "$LOG_FILE" ] && echo "$msg" >> "$LOG_FILE"
}

log_warning() {
    local msg="[$(date +'%Y-%m-%d %H:%M:%S')] [WARNING] $1"
    echo -e "${YELLOW}$msg${NC}"
    [ -n "$LOG_FILE" ] && echo "$msg" >> "$LOG_FILE"
}

log_error() {
    local msg="[$(date +'%Y-%m-%d %H:%M:%S')] [ERROR] $1"
    echo -e "${RED}$msg${NC}"
    [ -n "$LOG_FILE" ] && echo "$msg" >> "$LOG_FILE"
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -e|--environment)
            ENVIRONMENT="$2"
            shift 2
            ;;
        -w|--watch|-c|--continuous)
            WATCH_MODE=true
            shift
            ;;
        -i|--interval)
            WATCH_INTERVAL="$2"
            shift 2
            ;;
        -f|--format)
            OUTPUT_FORMAT="$2"
            shift 2
            ;;
        -a|--alert-webhook)
            ALERT_WEBHOOK="$2"
            shift 2
            ;;
        -l|--log-file)
            LOG_FILE="$2"
            shift 2
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            usage
            exit 1
            ;;
    esac
done

# Validate environment
case $ENVIRONMENT in
    develop|staging|production|all)
        ;;
    *)
        log_error "Invalid environment: $ENVIRONMENT"
        log_error "Valid environments: develop, staging, production, all"
        exit 1
        ;;
esac

# Validate output format
case $OUTPUT_FORMAT in
    text|json|prometheus)
        ;;
    *)
        log_error "Invalid output format: $OUTPUT_FORMAT"
        log_error "Valid formats: text, json, prometheus"
        exit 1
        ;;
esac

# Get environments to monitor
get_environments() {
    if [ "$ENVIRONMENT" = "all" ]; then
        echo "develop staging production"
    else
        echo "$ENVIRONMENT"
    fi
}

# Get Vault endpoint for environment
get_vault_endpoint() {
    local env=$1
    case $env in
        develop)
            echo "http://localhost:8200"
            ;;
        staging)
            echo "https://localhost:8210"
            ;;
        production)
            echo "https://localhost:8220"
            ;;
    esac
}

# Check Nomad job status
check_nomad_job() {
    local env=$1
    local job_name="vault-$env"
    local result=()
    
    log_info "Checking Nomad job status for $env..."
    
    # Check if Nomad is available
    if ! command -v nomad &> /dev/null; then
        result+=("nomad_available:false")
        result+=("nomad_error:cli_not_found")
        echo "${result[@]}"
        return 1
    fi
    
    # Check if we can connect to Nomad
    if ! nomad node status &> /dev/null; then
        result+=("nomad_available:false")
        result+=("nomad_error:cannot_connect")
        echo "${result[@]}"
        return 1
    fi
    
    result+=("nomad_available:true")
    
    # Check if job exists
    if ! nomad job status "$job_name" &> /dev/null; then
        result+=("job_exists:false")
        result+=("job_status:not_found")
        echo "${result[@]}"
        return 1
    fi
    
    result+=("job_exists:true")
    
    # Get job status
    local job_status=$(nomad job status "$job_name" 2>/dev/null | grep "Status" | awk '{print $3}' || echo "unknown")
    result+=("job_status:$job_status")
    
    # Get allocation count
    local running_allocs=$(nomad job status "$job_name" 2>/dev/null | grep -c "running" || echo "0")
    local total_allocs=$(nomad job status "$job_name" 2>/dev/null | grep -E "(running|pending|failed)" | wc -l || echo "0")
    
    result+=("running_allocations:$running_allocs")
    result+=("total_allocations:$total_allocs")
    
    # Check if healthy
    if [ "$job_status" = "running" ] && [ "$running_allocs" -gt 0 ]; then
        result+=("nomad_healthy:true")
        echo "${result[@]}"
        return 0
    else
        result+=("nomad_healthy:false")
        echo "${result[@]}"
        return 1
    fi
}

# Check Vault HTTP health
check_vault_http() {
    local env=$1
    local vault_addr=$(get_vault_endpoint "$env")
    local result=()
    
    log_info "Checking Vault HTTP health for $env at $vault_addr..."
    
    result+=("vault_addr:$vault_addr")
    
    # Set curl options based on environment
    local curl_opts="-s -f --max-time 10"
    if [[ $vault_addr == https://* ]]; then
        curl_opts="$curl_opts -k"  # Allow self-signed certs
    fi
    
    # Check /v1/sys/health endpoint
    local health_url="$vault_addr/v1/sys/health"
    local http_response
    local http_code
    
    if http_response=$(curl $curl_opts -w "%{http_code}" "$health_url" 2>/dev/null); then
        http_code=$(echo "$http_response" | tail -n1)
        local response_body=$(echo "$http_response" | head -n -1)
        
        result+=("http_reachable:true")
        result+=("http_code:$http_code")
        
        # Parse health response if it's JSON
        if command -v jq &> /dev/null && echo "$response_body" | jq . &> /dev/null; then
            local initialized=$(echo "$response_body" | jq -r '.initialized // false')
            local sealed=$(echo "$response_body" | jq -r '.sealed // true')
            local standby=$(echo "$response_body" | jq -r '.standby // false')
            local version=$(echo "$response_body" | jq -r '.version // "unknown"')
            
            result+=("initialized:$initialized")
            result+=("sealed:$sealed")
            result+=("standby:$standby")
            result+=("version:$version")
            
            # Determine overall health
            if [ "$initialized" = "true" ] && [ "$sealed" = "false" ]; then
                result+=("vault_healthy:true")
                echo "${result[@]}"
                return 0
            else
                result+=("vault_healthy:false")
                if [ "$initialized" = "false" ]; then
                    result+=("health_issue:not_initialized")
                elif [ "$sealed" = "true" ]; then
                    result+=("health_issue:sealed")
                fi
                echo "${result[@]}"
                return 1
            fi
        else
            # Non-JSON response, check HTTP code
            case $http_code in
                200)
                    result+=("vault_healthy:true")
                    echo "${result[@]}"
                    return 0
                    ;;
                429|472|473|503)
                    result+=("vault_healthy:false")
                    result+=("health_issue:sealed_or_standby")
                    echo "${result[@]}"
                    return 1
                    ;;
                *)
                    result+=("vault_healthy:false")
                    result+=("health_issue:http_error")
                    echo "${result[@]}"
                    return 1
                    ;;
            esac
        fi
    else
        result+=("http_reachable:false")
        result+=("vault_healthy:false")
        result+=("health_issue:connection_failed")
        echo "${result[@]}"
        return 1
    fi
}

# Check Vault CLI
check_vault_cli() {
    local env=$1
    local vault_addr=$(get_vault_endpoint "$env")
    local result=()
    
    # Check if Vault CLI is available
    if ! command -v vault &> /dev/null; then
        result+=("vault_cli_available:false")
        echo "${result[@]}"
        return 1
    fi
    
    result+=("vault_cli_available:true")
    
    # Set Vault environment
    export VAULT_ADDR="$vault_addr"
    if [[ $vault_addr == https://* ]] && [ "$env" != "production" ]; then
        export VAULT_SKIP_VERIFY=true
    fi
    
    # Try vault status command
    local vault_output
    if vault_output=$(vault status -format=json 2>/dev/null); then
        result+=("vault_cli_reachable:true")
        
        if command -v jq &> /dev/null; then
            local initialized=$(echo "$vault_output" | jq -r '.initialized // false')
            local sealed=$(echo "$vault_output" | jq -r '.sealed // true')
            local version=$(echo "$vault_output" | jq -r '.version // "unknown"')
            
            result+=("cli_initialized:$initialized")
            result+=("cli_sealed:$sealed")
            result+=("cli_version:$version")
        fi
        
        echo "${result[@]}"
        return 0
    else
        result+=("vault_cli_reachable:false")
        echo "${result[@]}"
        return 1
    fi
}

# Perform comprehensive health check for an environment
check_environment_health() {
    local env=$1
    local timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
    
    log_info "=== Health Check for $env environment ==="
    
    # Initialize result structure
    local health_result=()
    health_result+=("environment:$env")
    health_result+=("timestamp:$timestamp")
    
    local overall_healthy=true
    local issues=()
    
    # Check Nomad job
    local nomad_result
    if nomad_result=$(check_nomad_job "$env"); then
        health_result+=($nomad_result)
        log_success "Nomad job check passed for $env"
    else
        health_result+=($nomad_result)
        overall_healthy=false
        issues+=("nomad_unhealthy")
        log_error "Nomad job check failed for $env"
    fi
    
    # Check Vault HTTP health
    local vault_http_result
    if vault_http_result=$(check_vault_http "$env"); then
        health_result+=($vault_http_result)
        log_success "Vault HTTP check passed for $env"
    else
        health_result+=($vault_http_result)
        overall_healthy=false
        issues+=("vault_http_unhealthy")
        log_error "Vault HTTP check failed for $env"
    fi
    
    # Check Vault CLI (optional)
    local vault_cli_result
    if vault_cli_result=$(check_vault_cli "$env"); then
        health_result+=($vault_cli_result)
        log_success "Vault CLI check passed for $env"
    else
        health_result+=($vault_cli_result)
        # CLI failure is not critical for overall health
        log_warning "Vault CLI check failed for $env (non-critical)"
    fi
    
    # Set overall health status
    health_result+=("overall_healthy:$overall_healthy")
    if [ ${#issues[@]} -gt 0 ]; then
        health_result+=("issues:${issues[*]}")
    fi
    
    # Store result globally
    HEALTH_STATUS+=("${health_result[*]}")
    
    # Generate alerts if needed
    if [ "$overall_healthy" = "false" ]; then
        ALERTS+=("CRITICAL: Vault $env environment is unhealthy - Issues: ${issues[*]}")
    fi
    
    return $([ "$overall_healthy" = "true" ] && echo 0 || echo 1)
}

# Output results in different formats
output_results() {
    case $OUTPUT_FORMAT in
        text)
            output_text_format
            ;;
        json)
            output_json_format
            ;;
        prometheus)
            output_prometheus_format
            ;;
    esac
}

# Text output format
output_text_format() {
    echo ""
    echo "=== Vault Health Check Results ==="
    echo "Timestamp: $(date)"
    echo ""
    
    for health_data in "${HEALTH_STATUS[@]}"; do
        local env=$(echo "$health_data" | grep -o 'environment:[^ ]*' | cut -d: -f2)
        local overall_healthy=$(echo "$health_data" | grep -o 'overall_healthy:[^ ]*' | cut -d: -f2)
        
        if [ "$overall_healthy" = "true" ]; then
            echo -e "${GREEN}✓ $env: HEALTHY${NC}"
        else
            echo -e "${RED}✗ $env: UNHEALTHY${NC}"
        fi
        
        # Show key metrics
        local job_status=$(echo "$health_data" | grep -o 'job_status:[^ ]*' | cut -d: -f2)
        local vault_healthy=$(echo "$health_data" | grep -o 'vault_healthy:[^ ]*' | cut -d: -f2)
        local initialized=$(echo "$health_data" | grep -o 'initialized:[^ ]*' | cut -d: -f2)
        local sealed=$(echo "$health_data" | grep -o 'sealed:[^ ]*' | cut -d: -f2)
        
        echo "  Job Status: $job_status"
        echo "  Vault Healthy: $vault_healthy"
        echo "  Initialized: $initialized"
        echo "  Sealed: $sealed"
        echo ""
    done
    
    # Show alerts
    if [ ${#ALERTS[@]} -gt 0 ]; then
        echo "=== Alerts ==="
        for alert in "${ALERTS[@]}"; do
            echo -e "${RED}⚠ $alert${NC}"
        done
        echo ""
    fi
}

# JSON output format
output_json_format() {
    local json_output='{"timestamp":"'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'","environments":['
    
    local first=true
    for health_data in "${HEALTH_STATUS[@]}"; do
        if [ "$first" = "false" ]; then
            json_output+=','
        fi
        first=false
        
        json_output+='{'
        
        local first_field=true
        IFS=' ' read -ra FIELDS <<< "$health_data"
        for field in "${FIELDS[@]}"; do
            local key=$(echo "$field" | cut -d: -f1)
            local value=$(echo "$field" | cut -d: -f2-)
            
            if [ "$first_field" = "false" ]; then
                json_output+=','
            fi
            first_field=false
            
            json_output+="\"$key\":\"$value\""
        done
        
        json_output+='}'
    done
    
    json_output+='],"alerts":['
    
    first=true
    for alert in "${ALERTS[@]}"; do
        if [ "$first" = "false" ]; then
            json_output+=','
        fi
        first=false
        json_output+="\"$alert\""
    done
    
    json_output+=']}'
    
    echo "$json_output" | jq . 2>/dev/null || echo "$json_output"
}

# Prometheus output format
output_prometheus_format() {
    local timestamp=$(date +%s)000  # Prometheus expects milliseconds
    
    echo "# HELP vault_health_status Vault health status (1 = healthy, 0 = unhealthy)"
    echo "# TYPE vault_health_status gauge"
    
    echo "# HELP vault_nomad_job_status Nomad job status (1 = running, 0 = not running)"
    echo "# TYPE vault_nomad_job_status gauge"
    
    echo "# HELP vault_initialized Vault initialization status (1 = initialized, 0 = not initialized)"
    echo "# TYPE vault_initialized gauge"
    
    echo "# HELP vault_sealed Vault seal status (1 = sealed, 0 = unsealed)"
    echo "# TYPE vault_sealed gauge"
    
    for health_data in "${HEALTH_STATUS[@]}"; do
        local env=$(echo "$health_data" | grep -o 'environment:[^ ]*' | cut -d: -f2)
        local overall_healthy=$(echo "$health_data" | grep -o 'overall_healthy:[^ ]*' | cut -d: -f2)
        local job_status=$(echo "$health_data" | grep -o 'job_status:[^ ]*' | cut -d: -f2)
        local initialized=$(echo "$health_data" | grep -o 'initialized:[^ ]*' | cut -d: -f2)
        local sealed=$(echo "$health_data" | grep -o 'sealed:[^ ]*' | cut -d: -f2)
        
        # Convert to numeric values
        local health_value=$([ "$overall_healthy" = "true" ] && echo 1 || echo 0)
        local job_value=$([ "$job_status" = "running" ] && echo 1 || echo 0)
        local init_value=$([ "$initialized" = "true" ] && echo 1 || echo 0)
        local seal_value=$([ "$sealed" = "true" ] && echo 1 || echo 0)
        
        echo "vault_health_status{environment=\"$env\"} $health_value $timestamp"
        echo "vault_nomad_job_status{environment=\"$env\"} $job_value $timestamp"
        echo "vault_initialized{environment=\"$env\"} $init_value $timestamp"
        echo "vault_sealed{environment=\"$env\"} $seal_value $timestamp"
    done
}

# Send alerts via webhook
send_alerts() {
    if [ -z "$ALERT_WEBHOOK" ] || [ ${#ALERTS[@]} -eq 0 ]; then
        return 0
    fi
    
    log_info "Sending alerts to webhook..."
    
    for alert in "${ALERTS[@]}"; do
        local payload='{"text":"'"$alert"'","timestamp":"'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'"}'
        
        if curl -s -X POST -H "Content-Type: application/json" -d "$payload" "$ALERT_WEBHOOK" > /dev/null; then
            log_success "Alert sent: $alert"
        else
            log_error "Failed to send alert: $alert"
        fi
    done
}

# Main monitoring loop
run_health_checks() {
    local environments
    environments=$(get_environments)
    
    # Clear previous results
    HEALTH_STATUS=()
    ALERTS=()
    
    local overall_success=true
    
    for env in $environments; do
        if ! check_environment_health "$env"; then
            overall_success=false
        fi
    done
    
    # Output results
    output_results
    
    # Send alerts if configured
    send_alerts
    
    return $([ "$overall_success" = "true" ] && echo 0 || echo 1)
}

# Watch mode
run_watch_mode() {
    log_info "Starting watch mode (interval: ${WATCH_INTERVAL}s)"
    
    while true; do
        run_health_checks
        
        if [ "$WATCH_MODE" = "true" ]; then
            log_info "Sleeping for $WATCH_INTERVAL seconds..."
            sleep "$WATCH_INTERVAL"
        else
            break
        fi
    done
}

# Cleanup on exit
cleanup() {
    log_info "Health monitoring stopped"
}

# Main execution
main() {
    log_info "Vault Health Monitor"
    log_info "Environment: $ENVIRONMENT"
    log_info "Watch mode: $WATCH_MODE"
    log_info "Output format: $OUTPUT_FORMAT"
    
    # Setup signal handlers
    trap cleanup EXIT INT TERM
    
    if [ "$WATCH_MODE" = "true" ]; then
        run_watch_mode
    else
        run_health_checks
    fi
}

# Execute main function
main "$@"