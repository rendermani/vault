#!/bin/bash
# Bootstrap script for Vault deployment across environments
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# Default values
ENVIRONMENT="develop"
DRY_RUN=false
VAULT_TOKEN=""
AUTO_APPROVE=false

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Usage function
usage() {
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  -e, --environment ENV    Environment to deploy (develop|staging|production) [default: develop]"
    echo "  -t, --token TOKEN        Vault token for authentication"
    echo "  -d, --dry-run           Show what would be deployed without executing"
    echo "  -y, --yes               Auto-approve deployment without prompts"
    echo "  -h, --help              Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 --environment develop"
    echo "  $0 --environment staging --token s.xyz123"
    echo "  $0 --environment production --dry-run"
    echo ""
}

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -e|--environment)
            ENVIRONMENT="$2"
            shift 2
            ;;
        -t|--token)
            VAULT_TOKEN="$2"
            shift 2
            ;;
        -d|--dry-run)
            DRY_RUN=true
            shift
            ;;
        -y|--yes)
            AUTO_APPROVE=true
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            usage
            exit 1
            ;;
    esac
done

# Validate environment
case $ENVIRONMENT in
    develop|staging|production)
        ;;
    *)
        log_error "Invalid environment: $ENVIRONMENT"
        log_error "Valid environments: develop, staging, production"
        exit 1
        ;;
esac

log_info "Starting Vault bootstrap for $ENVIRONMENT environment"

# Pre-deployment checks
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check if Nomad is available
    if ! command -v nomad &> /dev/null; then
        log_error "Nomad CLI not found. Please install Nomad."
        exit 1
    fi
    
    # Check if we can connect to Nomad
    if ! nomad node status &> /dev/null; then
        log_error "Cannot connect to Nomad cluster. Is Nomad agent running?"
        exit 1
    fi
    
    # Check if Vault CLI is available
    if ! command -v vault &> /dev/null; then
        log_warning "Vault CLI not found. Some post-deployment checks will be skipped."
    fi
    
    # Check if job file exists
    JOB_FILE="$PROJECT_ROOT/jobs/$ENVIRONMENT/vault.nomad"
    if [ ! -f "$JOB_FILE" ]; then
        log_error "Job file not found: $JOB_FILE"
        exit 1
    fi
    
    log_success "Prerequisites check passed"
}

# Validate job file
validate_job() {
    log_info "Validating Nomad job file..."
    
    if $DRY_RUN; then
        log_info "[DRY-RUN] Would validate: $JOB_FILE"
        return 0
    fi
    
    if ! nomad job validate "$JOB_FILE"; then
        log_error "Job validation failed for $JOB_FILE"
        exit 1
    fi
    
    log_success "Job validation passed"
}

# Plan deployment
plan_deployment() {
    log_info "Planning deployment..."
    
    if $DRY_RUN; then
        log_info "[DRY-RUN] Would plan deployment of: $JOB_FILE"
        return 0
    fi
    
    if ! nomad job plan "$JOB_FILE"; then
        log_error "Deployment planning failed"
        exit 1
    fi
    
    log_success "Deployment planning completed"
}

# Deploy Vault
deploy_vault() {
    log_info "Deploying Vault to $ENVIRONMENT environment..."
    
    if $DRY_RUN; then
        log_info "[DRY-RUN] Would deploy: $JOB_FILE"
        return 0
    fi
    
    if ! $AUTO_APPROVE; then
        echo ""
        log_warning "This will deploy Vault to the $ENVIRONMENT environment."
        read -p "Are you sure you want to continue? [y/N]: " -n 1 -r
        echo ""
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            log_info "Deployment cancelled by user"
            exit 0
        fi
    fi
    
    if ! nomad job run "$JOB_FILE"; then
        log_error "Deployment failed"
        exit 1
    fi
    
    log_success "Vault deployed successfully"
}

# Wait for deployment to be healthy
wait_for_deployment() {
    log_info "Waiting for deployment to be healthy..."
    
    if $DRY_RUN; then
        log_info "[DRY-RUN] Would wait for deployment to be healthy"
        return 0
    fi
    
    local job_name="vault-$ENVIRONMENT"
    local timeout=600  # 10 minutes
    local interval=10
    local elapsed=0
    
    while [ $elapsed -lt $timeout ]; do
        local status=$(nomad job status "$job_name" | grep "Status" | awk '{print $3}')
        
        if [ "$status" = "running" ]; then
            # Check if all allocations are healthy
            local healthy_allocs=$(nomad job status "$job_name" | grep -c "running")
            local total_allocs=$(nomad job status "$job_name" | grep -E "(running|pending|failed)" | wc -l)
            
            if [ "$healthy_allocs" -gt 0 ] && [ "$healthy_allocs" = "$total_allocs" ]; then
                log_success "Deployment is healthy"
                return 0
            fi
        fi
        
        log_info "Deployment status: $status (waiting... ${elapsed}s/${timeout}s)"
        sleep $interval
        elapsed=$((elapsed + interval))
    done
    
    log_error "Deployment did not become healthy within $timeout seconds"
    exit 1
}

# Post-deployment verification
verify_deployment() {
    log_info "Verifying deployment..."
    
    if $DRY_RUN; then
        log_info "[DRY-RUN] Would verify deployment"
        return 0
    fi
    
    local job_name="vault-$ENVIRONMENT"
    
    # Check job status
    if ! nomad job status "$job_name" &> /dev/null; then
        log_error "Job $job_name not found"
        return 1
    fi
    
    # Get service endpoint based on environment
    local vault_addr
    case $ENVIRONMENT in
        develop)
            vault_addr="http://localhost:8200"
            ;;
        staging)
            vault_addr="https://localhost:8210"
            ;;
        production)
            vault_addr="https://localhost:8220"
            ;;
    esac
    
    # Test Vault connectivity
    if command -v vault &> /dev/null; then
        export VAULT_ADDR="$vault_addr"
        
        if [ "$ENVIRONMENT" != "develop" ]; then
            export VAULT_SKIP_VERIFY=true  # For self-signed certs
        fi
        
        log_info "Testing Vault connectivity at $vault_addr"
        
        # Wait for Vault to be available
        local timeout=120
        local interval=5
        local elapsed=0
        
        while [ $elapsed -lt $timeout ]; do
            if vault status &> /dev/null; then
                log_success "Vault is accessible"
                break
            fi
            
            log_info "Waiting for Vault to be available... ${elapsed}s/${timeout}s"
            sleep $interval
            elapsed=$((elapsed + interval))
        done
        
        if [ $elapsed -ge $timeout ]; then
            log_warning "Could not connect to Vault within $timeout seconds"
            log_warning "This might be expected if Vault needs initialization"
        fi
        
        # Check Vault status
        if vault status; then
            log_success "Vault status check passed"
        else
            log_warning "Vault status check failed (might need initialization)"
        fi
    else
        log_info "Skipping Vault connectivity test (vault CLI not available)"
    fi
    
    log_success "Deployment verification completed"
}

# Generate post-deployment instructions
generate_instructions() {
    log_info "Generating post-deployment instructions..."
    
    local instructions_file="$PROJECT_ROOT/scripts/post-deployment-$ENVIRONMENT.md"
    
    cat > "$instructions_file" <<EOF
# Post-Deployment Instructions for $ENVIRONMENT Environment

Generated on: $(date)

## Vault Access

### Endpoint
EOF

    case $ENVIRONMENT in
        develop)
            cat >> "$instructions_file" <<EOF
- Internal: http://localhost:8200
- External: http://vault-develop.local:8200 (if configured)

### Next Steps for Development

1. **Initialize Vault** (if not auto-initialized):
   \`\`\`bash
   export VAULT_ADDR="http://localhost:8200"
   vault operator init
   \`\`\`

2. **Unseal Vault** (if not auto-unsealed):
   \`\`\`bash
   vault operator unseal <unseal-key-1>
   vault operator unseal <unseal-key-2>
   vault operator unseal <unseal-key-3>
   \`\`\`

3. **Login with root token**:
   \`\`\`bash
   vault auth <root-token>
   \`\`\`

4. **Test basic functionality**:
   \`\`\`bash
   vault secrets list
   vault write secret/myapp/config username="myuser" password="mypass"
   vault read secret/myapp/config
   \`\`\`
EOF
            ;;
        staging)
            cat >> "$instructions_file" <<EOF
- Internal: https://localhost:8210
- External: https://vault-staging.cloudya.net (if configured)

### Next Steps for Staging

1. **Initialize Vault** (manual process):
   \`\`\`bash
   export VAULT_ADDR="https://localhost:8210"
   export VAULT_SKIP_VERIFY=true  # For self-signed certs
   vault operator init -recovery-shares=5 -recovery-threshold=3
   \`\`\`

2. **Secure the recovery keys** - distribute among team members

3. **Run staging setup script**:
   \`\`\`bash
   export VAULT_TOKEN="<root-token>"
   # Access the running container and execute setup script
   nomad alloc exec <alloc-id> /local/setup-staging-policies.sh
   \`\`\`

4. **Configure monitoring and alerts**

5. **Test application integration**
EOF
            ;;
        production)
            cat >> "$instructions_file" <<EOF
- Internal: https://localhost:8220
- External: https://vault.cloudya.net

### CRITICAL Next Steps for Production

⚠️  **SECURITY CRITICAL**: Follow these steps in order

1. **Verify TLS certificates are properly installed**
2. **Initialize Vault** (ONE TIME ONLY):
   \`\`\`bash
   export VAULT_ADDR="https://localhost:8220"
   export VAULT_CACERT="/path/to/ca.pem"
   vault operator init -recovery-shares=5 -recovery-threshold=3
   \`\`\`

3. **IMMEDIATELY secure recovery keys**:
   - Split recovery keys among 5 trusted individuals
   - Store in secure offline storage
   - Remove from system after secure backup

4. **Run production setup script**:
   \`\`\`bash
   export VAULT_TOKEN="<root-token>"
   # Access the running container and execute setup script
   nomad alloc exec <alloc-id> /local/setup-production.sh
   \`\`\`

5. **REVOKE root token** after setup completion

6. **Configure monitoring, alerting, and logging**

7. **Set up automated backups**

8. **Test disaster recovery procedures**

9. **Complete security audit and compliance check**
EOF
            ;;
    esac

    cat >> "$instructions_file" <<EOF

## Monitoring

### Check Deployment Status
\`\`\`bash
nomad job status vault-$ENVIRONMENT
\`\`\`

### View Logs
\`\`\`bash
nomad alloc logs <alloc-id> vault
\`\`\`

### Check Vault Status
\`\`\`bash
vault status
\`\`\`

## Troubleshooting

### Common Issues
1. **Vault sealed**: Use unseal keys to unseal
2. **TLS errors**: Check certificate configuration
3. **Permission errors**: Verify volume permissions
4. **Network issues**: Check Nomad network configuration

### Getting Help
- Check Nomad job logs
- Verify Vault configuration
- Review network connectivity
- Check resource constraints

---
Generated by Vault Bootstrap Script
EOF

    log_success "Instructions written to: $instructions_file"
    
    if ! $DRY_RUN; then
        log_info "Opening instructions file..."
        if command -v code &> /dev/null; then
            code "$instructions_file" &
        elif command -v cat &> /dev/null; then
            echo ""
            log_info "=== POST-DEPLOYMENT INSTRUCTIONS ==="
            cat "$instructions_file"
        fi
    fi
}

# Cleanup function for failed deployments
cleanup_failed_deployment() {
    log_warning "Cleaning up failed deployment..."
    
    if $DRY_RUN; then
        log_info "[DRY-RUN] Would cleanup failed deployment"
        return 0
    fi
    
    local job_name="vault-$ENVIRONMENT"
    
    if nomad job status "$job_name" &> /dev/null; then
        log_info "Stopping job: $job_name"
        nomad job stop "$job_name" || true
        
        # Wait for job to stop
        sleep 10
        
        # Purge job history
        nomad job stop -purge "$job_name" || true
    fi
    
    log_info "Cleanup completed"
}

# Main execution
main() {
    log_info "Vault Bootstrap Script"
    log_info "Environment: $ENVIRONMENT"
    log_info "Dry Run: $DRY_RUN"
    
    # Export job file path for use in other functions
    export JOB_FILE="$PROJECT_ROOT/jobs/$ENVIRONMENT/vault.nomad"
    
    # Trap for cleanup on failure
    trap cleanup_failed_deployment ERR
    
    # Execute deployment steps
    check_prerequisites
    validate_job
    plan_deployment
    
    if ! $DRY_RUN; then
        deploy_vault
        wait_for_deployment
        verify_deployment
    fi
    
    generate_instructions
    
    # Remove trap
    trap - ERR
    
    log_success "Vault bootstrap completed successfully!"
    
    if [ "$ENVIRONMENT" = "production" ]; then
        echo ""
        log_warning "🔐 PRODUCTION DEPLOYMENT COMPLETED"
        log_warning "Don't forget to:"
        log_warning "1. Secure recovery keys immediately"
        log_warning "2. Revoke root token after setup"
        log_warning "3. Configure monitoring and backups"
        log_warning "4. Complete security audit"
    fi
}

# Execute main function
main "$@"