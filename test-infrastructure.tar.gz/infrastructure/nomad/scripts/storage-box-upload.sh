#!/bin/bash

# Storage Box Upload Script
# Uploads files to Hetzner Storage Box via SSH/SCP

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration - Pull from Vault
VAULT_TOKEN=${VAULT_TOKEN:-}

# Get credentials from Vault
echo -e "${BLUE}Retrieving credentials from Vault...${NC}"
STORAGE_HOST=$(docker exec -e VAULT_TOKEN=$VAULT_TOKEN vault-cloudya-final vault kv get -field=host secret/development/storage-box 2>/dev/null || echo "u483283.your-storagebox.de")
STORAGE_USER=$(docker exec -e VAULT_TOKEN=$VAULT_TOKEN vault-cloudya-final vault kv get -field=username secret/development/storage-box 2>/dev/null || echo "")
STORAGE_PASS=$(docker exec -e VAULT_TOKEN=$VAULT_TOKEN vault-cloudya-final vault kv get -field=password secret/development/storage-box 2>/dev/null || echo "")
STORAGE_PORT="23"

if [ -z "$STORAGE_USER" ] || [ -z "$STORAGE_PASS" ]; then
    echo -e "${RED}Error: Could not retrieve storage box credentials from Vault${NC}"
    echo "Please ensure credentials are stored at secret/development/storage-box"
    exit 1
fi

echo -e "${BLUE}📁 Storage Box Upload Tool${NC}"
echo "=========================="
echo ""

# Function to upload file via SCP
upload_file() {
    local source_file="$1"
    local dest_path="$2"
    
    echo -e "${BLUE}Uploading $source_file to $dest_path...${NC}"
    
    # Use sshpass for password authentication
    SSHPASS="$STORAGE_PASS" sshpass -e scp -P $STORAGE_PORT -o StrictHostKeyChecking=no \
        "$source_file" "$STORAGE_USER@$STORAGE_HOST:$dest_path"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ Upload successful${NC}"
    else
        echo -e "${RED}✗ Upload failed${NC}"
        return 1
    fi
}

# Function to create directory on storage box
create_directory() {
    local dir_path="$1"
    
    echo -e "${BLUE}Creating directory $dir_path...${NC}"
    
    expect -c "
        spawn ssh -p $STORAGE_PORT $STORAGE_USER@$STORAGE_HOST
        expect \"password:\"
        send \"$STORAGE_PASS\r\"
        expect \">\"
        send \"mkdir -p $dir_path\r\"
        expect \">\"
        send \"exit\r\"
        expect eof
    " > /dev/null
}

# Function to list storage box contents
list_contents() {
    local path="${1:-/home}"
    
    echo -e "${BLUE}Listing contents of $path...${NC}"
    
    expect -c "
        spawn ssh -p $STORAGE_PORT $STORAGE_USER@$STORAGE_HOST
        expect \"password:\"
        send \"$STORAGE_PASS\r\"
        expect \">\"
        send \"cd $path\r\"
        expect \">\"
        send \"ls -la\r\"
        expect \">\"
        send \"exit\r\"
        expect eof
    "
}

# Function to test connection
test_connection() {
    echo -e "${BLUE}Testing storage box connection...${NC}"
    
    if expect -c "
        spawn ssh -p $STORAGE_PORT $STORAGE_USER@$STORAGE_HOST
        expect \"password:\"
        send \"$STORAGE_PASS\r\"
        expect \">\"
        send \"echo 'Connection successful'\r\"
        expect \"Connection successful\"
        send \"exit\r\"
        expect eof
    " > /dev/null 2>&1; then
        echo -e "${GREEN}✓ Connection successful${NC}"
        return 0
    else
        echo -e "${RED}✗ Connection failed${NC}"
        return 1
    fi
}

# Function to sync directory using rsync over SSH
sync_directory() {
    local source_dir="$1"
    local dest_dir="$2"
    
    echo -e "${BLUE}Syncing $source_dir to $dest_dir...${NC}"
    echo -e "${YELLOW}This may take a while for large directories${NC}"
    
    # First create destination directory
    create_directory "$dest_dir"
    
    # Use rsync with SSH
    SSHPASS="$STORAGE_PASS" rsync -avz --progress \
        -e "sshpass -e ssh -p $STORAGE_PORT -o StrictHostKeyChecking=no" \
        "$source_dir/" "$STORAGE_USER@$STORAGE_HOST:$dest_dir/"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ Sync completed${NC}"
    else
        echo -e "${RED}✗ Sync failed${NC}"
        return 1
    fi
}

# Handle command line arguments
case "$1" in
    test)
        test_connection
        ;;
    list)
        list_contents "$2"
        ;;
    upload)
        if [ -z "$2" ] || [ -z "$3" ]; then
            echo "Usage: $0 upload <source_file> <dest_path>"
            exit 1
        fi
        upload_file "$2" "$3"
        ;;
    sync)
        if [ -z "$2" ] || [ -z "$3" ]; then
            echo "Usage: $0 sync <source_dir> <dest_dir>"
            exit 1
        fi
        sync_directory "$2" "$3"
        ;;
    mkdir)
        if [ -z "$2" ]; then
            echo "Usage: $0 mkdir <directory_path>"
            exit 1
        fi
        create_directory "$2"
        ;;
    *)
        echo "Usage: $0 {test|list|upload|sync|mkdir}"
        echo ""
        echo "Commands:"
        echo "  test                    - Test connection to storage box"
        echo "  list [path]             - List contents (default: /home)"
        echo "  upload <file> <path>    - Upload single file"
        echo "  sync <src_dir> <dst_dir>- Sync directory"
        echo "  mkdir <path>            - Create directory"
        exit 1
        ;;
esac