# Nomad Production Jobs

This directory contains production-ready Nomad job files for deploying Vault and Traefik in a cloud-native infrastructure setup.

## 🚀 Quick Start

```bash
# 1. Validate job configurations
make validate

# 2. Setup host volumes and prerequisites  
make setup

# 3. Deploy both services
make deploy-all

# 4. Check status
make status
```

## 📁 Files Overview

| File | Description |
|------|-------------|
| `vault-production.nomad` | Production Vault deployment with TLS, persistence, and monitoring |
| `traefik-production.nomad` | Production Traefik with Let's Encrypt, service discovery, and security |
| `Makefile` | Easy deployment and management commands |
| `DEPLOYMENT_GUIDE.md` | Comprehensive deployment documentation |

## 🔧 Job Configurations

### Vault Production Job

**Key Features:**
- ✅ Raft storage for single-node deployment
- ✅ TLS encryption (requires certificates)
- ✅ Consul service registration
- ✅ Health checks and monitoring
- ✅ Persistent storage via host volumes
- ✅ JSON logging with rotation
- ✅ Traefik integration tags

**Network:**
- Port 8200: HTTPS API
- Port 8201: Cluster communication

**Volumes:**
- `vault-data`: Persistent data storage
- `vault-config`: Configuration files
- `vault-logs`: Log files
- `vault-certs`: TLS certificates (read-only)

### Traefik Production Job

**Key Features:**
- ✅ HTTP to HTTPS redirect
- ✅ Let's Encrypt automatic SSL
- ✅ Consul service discovery
- ✅ Vault backend routing (HTTPS)
- ✅ Security headers middleware
- ✅ Prometheus metrics
- ✅ Dashboard with authentication

**Network:**
- Port 80: HTTP (redirects to HTTPS)
- Port 443: HTTPS
- Port 8080: API/Dashboard
- Port 8082: Metrics

**Routing:**
- `vault.cloudya.net` → Vault service
- `traefik.cloudya.net` → Dashboard

## 🛠️ Prerequisites

1. **Nomad Cluster**: Running with Consul integration
2. **SSL Certificates**: Valid certificates for vault.cloudya.net
3. **DNS Records**: Proper domain configuration
4. **Host Volumes**: Storage directories with correct permissions

## 📋 Makefile Commands

| Command | Description |
|---------|-------------|
| `make help` | Show available commands |
| `make validate` | Validate job file syntax |
| `make setup` | Create host volumes and prerequisites |
| `make deploy-traefik` | Deploy Traefik load balancer |
| `make deploy-vault` | Deploy Vault secrets manager |
| `make deploy-all` | Deploy both services |
| `make status` | Show deployment status |
| `make health` | Check service health |
| `make logs-vault` | Show Vault logs |
| `make logs-traefik` | Show Traefik logs |
| `make stop` | Stop all jobs |
| `make cleanup` | Clean up stopped jobs |

## 🔐 Security Configuration

### Vault Security
- TLS encryption for all communications
- Proper file permissions on certificates
- Service isolation via Docker
- Health check monitoring
- Audit logging capability

### Traefik Security  
- Modern TLS configuration (TLS 1.2+)
- Security headers middleware
- Basic authentication for dashboard
- Let's Encrypt certificate automation
- Backend service verification

## 📊 Monitoring Integration

Both services provide Prometheus metrics:

- **Vault**: `/v1/sys/metrics`
- **Traefik**: Port 8082 `/metrics`

Health checks are configured for both services with automatic restarts on failure.

## 🏗️ Architecture

```
Internet
   │
   ▼
[Traefik:443] ─── HTTPS ───┐
   │                       │
   ▼                       ▼
[Let's Encrypt]      [vault.cloudya.net]
                           │
                           ▼
                    [Vault:8200] ◄── TLS ──► [Storage]
                           │
                           ▼
                    [Consul Service Discovery]
```

## 🚨 Production Checklist

Before deploying to production:

- [ ] SSL certificates installed and valid
- [ ] DNS records configured
- [ ] Host volumes created with correct permissions
- [ ] Nomad cluster healthy
- [ ] Consul cluster accessible
- [ ] Firewall rules configured
- [ ] Monitoring configured
- [ ] Backup procedures in place
- [ ] Incident response plan ready

## 🔍 Troubleshooting

### Common Issues

1. **Job Validation Fails**
   ```bash
   # Check syntax
   nomad job validate vault-production.nomad
   ```

2. **Service Not Accessible**
   ```bash
   # Check service registration
   consul catalog services
   nomad job status vault-production
   ```

3. **Certificate Issues**
   ```bash
   # Verify certificates
   openssl x509 -in /opt/nomad/volumes/vault-certs/vault.crt -text -noout
   ```

4. **Volume Permission Issues**
   ```bash
   # Fix permissions
   sudo chown -R vault:vault /opt/nomad/volumes/vault-*
   ```

### Log Locations

- **Nomad**: `nomad alloc logs <alloc-id>`
- **Vault**: `/opt/nomad/volumes/vault-logs/`
- **System**: `journalctl -u nomad`

## 📚 Additional Resources

- [DEPLOYMENT_GUIDE.md](./DEPLOYMENT_GUIDE.md) - Detailed deployment instructions
- [Vault Documentation](https://www.vaultproject.io/docs)
- [Traefik Documentation](https://doc.traefik.io/traefik/)
- [Nomad Documentation](https://www.nomadproject.io/docs)

## 🤝 Contributing

When modifying these job files:

1. Validate syntax with `make validate`
2. Test in development environment first
3. Update documentation
4. Follow security best practices
5. Test health checks and monitoring

## 📞 Support

For deployment issues:

1. Check job validation: `make validate`
2. Verify prerequisites: `make setup`  
3. Check service health: `make health`
4. Review logs: `make logs-vault` or `make logs-traefik`
5. Consult the deployment guide for detailed troubleshooting