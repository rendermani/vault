# Nomad Job Deployment Guide

This guide covers the deployment of Vault and Traefik using the production-ready Nomad job files.

## Prerequisites

1. **Nomad Cluster**: Running Nomad cluster with Consul integration
2. **Consul**: Service discovery and health checking
3. **SSL Certificates**: Valid certificates for vault.cloudya.net
4. **DNS**: Proper DNS records pointing to your Nomad cluster
5. **Host Volumes**: Configured host volumes for persistent storage

## Quick Start

### 1. Setup Host Volumes

```bash
# Run the setup script to create required directories and volumes
sudo ./scripts/setup-host-volumes.sh
```

### 2. Install SSL Certificates

Place your SSL certificates in the vault-certs volume:

```bash
# Copy certificates to vault directory
sudo cp vault.crt /opt/nomad/volumes/vault-certs/
sudo cp vault.key /opt/nomad/volumes/vault-certs/
sudo cp vault-ca.pem /opt/nomad/volumes/vault-certs/

# Set proper permissions
sudo chown vault:vault /opt/nomad/volumes/vault-certs/*
sudo chmod 600 /opt/nomad/volumes/vault-certs/*.key
sudo chmod 644 /opt/nomad/volumes/vault-certs/*.crt
sudo chmod 644 /opt/nomad/volumes/vault-certs/*.pem
```

### 3. Deploy Jobs

```bash
# Deploy Traefik first (provides load balancing)
nomad job run traefik-production.nomad

# Wait for Traefik to be healthy
nomad job status traefik-production

# Deploy Vault
nomad job run vault-production.nomad

# Check deployment status
nomad job status vault-production
```

## Job Files Overview

### vault-production.nomad

**Features:**
- Single-node Vault with Raft storage
- TLS encryption for API and cluster communication
- Consul service registration with health checks
- Persistent storage via host volumes
- JSON logging with rotation
- Prometheus metrics integration
- Traefik integration tags

**Ports:**
- 8200: Vault API (HTTPS)
- 8201: Vault cluster communication

**Health Checks:**
- HTTP health check on `/v1/sys/health?standbyok=true`
- TCP connectivity check

### traefik-production.nomad

**Features:**
- HTTP to HTTPS redirect
- Let's Encrypt automatic SSL certificates
- Consul service discovery
- Vault backend routing with HTTPS
- Security headers middleware
- Prometheus metrics
- Dashboard with basic auth

**Ports:**
- 80: HTTP (redirects to HTTPS)
- 443: HTTPS
- 8080: API/Dashboard
- 8082: Prometheus metrics

**Routing:**
- `vault.cloudya.net` → Vault service (HTTPS backend)
- `traefik.cloudya.net` → Traefik dashboard

## Configuration Details

### Vault Configuration

The Vault job includes:

1. **Raft Storage**: Single-node configuration with data persistence
2. **TLS Listeners**: Both API and cluster endpoints use TLS
3. **Service Discovery**: Automatic registration with Consul
4. **Health Monitoring**: Multiple health check types
5. **Logging**: JSON format with log rotation
6. **Metrics**: Prometheus integration for monitoring

### Traefik Configuration

The Traefik job includes:

1. **Static Configuration**: Basic Traefik setup with providers
2. **Dynamic Configuration**: Service routing and middleware
3. **Let's Encrypt**: Automatic SSL certificate management
4. **Service Discovery**: Consul integration for backend services
5. **Security**: Modern TLS configuration and security headers

## Post-Deployment Steps

### 1. Initialize Vault

```bash
# Access Vault through Traefik
export VAULT_ADDR="https://vault.cloudya.net"

# Initialize Vault (first time only)
vault operator init

# Unseal Vault (if not using auto-unseal)
vault operator unseal <key1>
vault operator unseal <key2>
vault operator unseal <key3>
```

### 2. Configure Basic Policies

```bash
# Login with root token
vault auth <root_token>

# Enable basic secret engines
vault secrets enable -path=secret kv-v2
vault auth enable approle

# Create basic policies
vault policy write admin-policy - <<EOF
path "*" {
  capabilities = ["create", "read", "update", "delete", "list", "sudo"]
}
EOF
```

### 3. Verify Services

```bash
# Check Nomad job status
nomad job status vault-production
nomad job status traefik-production

# Check Consul services
consul catalog services
consul health service vault
consul health service traefik

# Test endpoints
curl -k https://vault.cloudya.net/v1/sys/health
curl https://traefik.cloudya.net/ping
```

## Troubleshooting

### Common Issues

1. **Certificate Problems**
   ```bash
   # Check certificate validity
   openssl x509 -in /opt/nomad/volumes/vault-certs/vault.crt -text -noout
   
   # Verify certificate matches key
   openssl x509 -noout -modulus -in vault.crt | openssl md5
   openssl rsa -noout -modulus -in vault.key | openssl md5
   ```

2. **Service Discovery Issues**
   ```bash
   # Check Consul connectivity
   consul members
   consul catalog services
   
   # Check service registration
   curl http://localhost:8500/v1/agent/services
   ```

3. **Volume Permissions**
   ```bash
   # Check volume ownership and permissions
   ls -la /opt/nomad/volumes/
   
   # Fix permissions if needed
   sudo chown -R vault:vault /opt/nomad/volumes/vault-*
   sudo chown -R traefik:traefik /opt/nomad/volumes/traefik-*
   ```

### Log Locations

- **Nomad logs**: `nomad alloc logs <alloc-id> <task>`
- **Vault logs**: `/opt/nomad/volumes/vault-logs/vault.log`
- **System logs**: `journalctl -u nomad`

## Security Considerations

1. **Change Default Passwords**: Update Traefik dashboard credentials
2. **Restrict Network Access**: Use firewall rules to limit access
3. **Monitor Audit Logs**: Enable and monitor Vault audit logs
4. **Regular Backups**: Implement automated backup procedures
5. **Certificate Rotation**: Plan for certificate renewal
6. **Secret Management**: Use proper secret injection methods

## Monitoring

Both services expose Prometheus metrics:

- **Vault metrics**: `https://vault.cloudya.net/v1/sys/metrics`
- **Traefik metrics**: `http://localhost:8082/metrics`

Configure your monitoring stack to scrape these endpoints for operational visibility.

## High Availability

For production high availability:

1. **Multiple Nomad Nodes**: Deploy across multiple nodes
2. **Vault Clustering**: Enable Vault HA with multiple instances
3. **Load Balancer**: Use external load balancer for Traefik
4. **Database Backend**: Consider Consul or external database for Vault storage
5. **Backup Strategy**: Implement regular backup procedures

## Support

For issues or questions:

1. Check Nomad job logs: `nomad alloc logs <alloc-id>`
2. Verify service health: `consul health service <service-name>`
3. Review configuration files in this repository
4. Consult HashiCorp documentation for Nomad, Vault, and Consul