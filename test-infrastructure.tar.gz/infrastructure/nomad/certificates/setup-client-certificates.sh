#!/bin/bash

# Client Certificate Setup for CloudYa Internal Network
# Creates and manages client certificates for enhanced security

set -e

# Configuration
CLOUDYA_DOMAIN="${CLOUDYA_DOMAIN:-cloudya.net}"
CA_DIR="/opt/cloudya/certificates/ca"
CLIENT_DIR="/opt/cloudya/certificates/clients"
VAULT_ADDR="${VAULT_ADDR:-https://vault.cloudya.net}"

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}🔐 CloudYa Client Certificate Setup${NC}"
echo "Domain: $CLOUDYA_DOMAIN"
echo "CA Directory: $CA_DIR"
echo "Client Directory: $CLIENT_DIR"
echo ""

# Function to log with timestamp
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

# Function to create directories
create_directories() {
    log "📁 Creating certificate directories..."
    
    sudo mkdir -p "$CA_DIR"
    sudo mkdir -p "$CLIENT_DIR"
    sudo mkdir -p "$CLIENT_DIR/github-runner"
    sudo mkdir -p "$CLIENT_DIR/admin"
    
    # Set proper permissions
    sudo chmod 755 "$CA_DIR"
    sudo chmod 750 "$CLIENT_DIR"
    
    log "✅ Directories created"
}

# Function to create CA certificate if not exists
create_ca_certificate() {
    if [[ -f "$CA_DIR/ca.crt" && -f "$CA_DIR/ca.key" ]]; then
        log "📜 CA certificate already exists"
        return 0
    fi
    
    log "🏗️  Creating CloudYa Certificate Authority..."
    
    # Generate CA private key
    sudo openssl genrsa -out "$CA_DIR/ca.key" 4096
    sudo chmod 600 "$CA_DIR/ca.key"
    
    # Create CA certificate
    sudo openssl req -new -x509 -days 3650 -key "$CA_DIR/ca.key" -out "$CA_DIR/ca.crt" -subj "/C=DE/ST=CloudYa/L=CloudYa/O=CloudYa Infrastructure/OU=Certificate Authority/CN=CloudYa Root CA"
    sudo chmod 644 "$CA_DIR/ca.crt"
    
    log "✅ CA certificate created"
    
    # Store CA certificate in Vault
    if command -v vault >/dev/null 2>&1; then
        log "🔐 Storing CA certificate in Vault..."
        CA_CERT_B64=$(sudo base64 -w 0 "$CA_DIR/ca.crt")
        
        vault kv put secret/cloudya/certificates/ca \
            certificate="$CA_CERT_B64" \
            created_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
            valid_until="$(date -d '+10 years' +%Y-%m-%dT%H:%M:%SZ)" \
            description="CloudYa Certificate Authority root certificate"
            
        log "✅ CA certificate stored in Vault"
    fi
}

# Function to create client certificate
create_client_certificate() {
    local client_name="$1"
    local client_type="${2:-client}"
    local validity_days="${3:-365}"
    
    log "📋 Creating client certificate for: $client_name"
    
    local client_key="$CLIENT_DIR/$client_name/$client_name.key"
    local client_csr="$CLIENT_DIR/$client_name/$client_name.csr"
    local client_crt="$CLIENT_DIR/$client_name/$client_name.crt"
    local client_p12="$CLIENT_DIR/$client_name/$client_name.p12"
    
    # Create client directory
    sudo mkdir -p "$CLIENT_DIR/$client_name"
    
    # Generate client private key
    sudo openssl genrsa -out "$client_key" 2048
    sudo chmod 600 "$client_key"
    
    # Create certificate signing request
    sudo openssl req -new -key "$client_key" -out "$client_csr" \
        -subj "/C=DE/ST=CloudYa/L=CloudYa/O=CloudYa Infrastructure/OU=$client_type/CN=$client_name"
    
    # Create extensions file for client certificate
    cat > "/tmp/$client_name.ext" << EOF
basicConstraints = CA:FALSE
keyUsage = nonRepudiation, digitalSignature, keyEncipherment
subjectAltName = @alt_names
extendedKeyUsage = clientAuth

[alt_names]
DNS.1 = $client_name
DNS.2 = $client_name.$CLOUDYA_DOMAIN
EOF

    # Sign the certificate with CA
    sudo openssl x509 -req -in "$client_csr" -CA "$CA_DIR/ca.crt" -CAkey "$CA_DIR/ca.key" \
        -CAcreateserial -out "$client_crt" -days "$validity_days" \
        -extensions v3_req -extfile "/tmp/$client_name.ext"
    
    sudo chmod 644 "$client_crt"
    
    # Create PKCS#12 bundle (for easier client installation)
    sudo openssl pkcs12 -export -out "$client_p12" \
        -inkey "$client_key" -in "$client_crt" -certfile "$CA_DIR/ca.crt" \
        -passout pass:cloudya-$client_name
    
    sudo chmod 600 "$client_p12"
    
    # Clean up
    sudo rm "$client_csr"
    rm "/tmp/$client_name.ext"
    
    log "✅ Client certificate created for $client_name"
    
    # Store in Vault
    if command -v vault >/dev/null 2>&1; then
        log "🔐 Storing client certificate in Vault..."
        
        CLIENT_CERT_B64=$(sudo base64 -w 0 "$client_crt")
        CLIENT_KEY_B64=$(sudo base64 -w 0 "$client_key")
        CLIENT_P12_B64=$(sudo base64 -w 0 "$client_p12")
        
        vault kv put "secret/cloudya/certificates/clients/$client_name" \
            certificate="$CLIENT_CERT_B64" \
            private_key="$CLIENT_KEY_B64" \
            pkcs12="$CLIENT_P12_B64" \
            pkcs12_password="cloudya-$client_name" \
            client_type="$client_type" \
            created_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
            valid_until="$(date -d "+$validity_days days" +%Y-%m-%dT%H:%M:%SZ)" \
            description="Client certificate for $client_name ($client_type)"
            
        log "✅ Client certificate stored in Vault"
    fi
}

# Function to update Traefik configuration for client certificates
update_traefik_config() {
    log "⚙️  Updating Traefik configuration for client certificates..."
    
    # Create client certificate middleware configuration
    cat > "/tmp/client-cert-middleware.yaml" << EOF
# Client Certificate Authentication Middleware
http:
  middlewares:
    # GitHub Runner Client Certificate Auth
    runner-client-cert:
      plugin:
        client-cert-auth:
          ca_cert_file: /certificates/ca/ca.crt
          client_cert_required: true
          verify_client_cert: true
          allowed_dns_names:
            - github-runner
            - github-runner.cloudya.net
    
    # Admin Client Certificate Auth
    admin-client-cert:
      plugin:
        client-cert-auth:
          ca_cert_file: /certificates/ca/ca.crt
          client_cert_required: true
          verify_client_cert: true
          allowed_dns_names:
            - admin
            - admin.cloudya.net
    
    # Combined Auth (Client Cert + Basic Auth)
    full-security:
      chain:
        middlewares:
          - runner-client-cert
          - internal-ratelimit
          - admin-access

# TLS Configuration with Client Certificates
tls:
  options:
    client-cert-required:
      minVersion: "VersionTLS12"
      cipherSuites:
        - "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384"
        - "TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305"
        - "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256"
      clientAuth:
        caFiles:
          - /certificates/ca/ca.crt
        clientAuthType: RequireAndVerifyClientCert
EOF

    # Copy to shared volume for Traefik
    if [[ -d "/shared" ]]; then
        sudo cp "/tmp/client-cert-middleware.yaml" "/shared/"
        log "✅ Client certificate middleware configuration updated"
    else
        log "⚠️  Shared volume not found, configuration saved to /tmp/client-cert-middleware.yaml"
    fi
    
    rm "/tmp/client-cert-middleware.yaml"
}

# Function to create certificate deployment script
create_deployment_script() {
    log "📝 Creating certificate deployment script..."
    
    cat > "/tmp/deploy-certificates.sh" << 'EOF'
#!/bin/bash

# Deploy client certificates to CloudYa services
set -e

VAULT_ADDR="${VAULT_ADDR:-https://vault.cloudya.net}"
CERT_DIR="/opt/cloudya/certificates"

# Function to deploy certificate from Vault
deploy_cert_from_vault() {
    local client_name="$1"
    local target_dir="$2"
    
    echo "📦 Deploying certificate for $client_name to $target_dir..."
    
    # Create target directory
    mkdir -p "$target_dir"
    
    # Get certificate from Vault
    vault kv get -format=json "secret/cloudya/certificates/clients/$client_name" > "/tmp/$client_name-cert.json"
    
    # Extract and decode certificates
    jq -r '.data.data.certificate' "/tmp/$client_name-cert.json" | base64 -d > "$target_dir/$client_name.crt"
    jq -r '.data.data.private_key' "/tmp/$client_name-cert.json" | base64 -d > "$target_dir/$client_name.key"
    jq -r '.data.data.pkcs12' "/tmp/$client_name-cert.json" | base64 -d > "$target_dir/$client_name.p12"
    
    # Set proper permissions
    chmod 644 "$target_dir/$client_name.crt"
    chmod 600 "$target_dir/$client_name.key"
    chmod 600 "$target_dir/$client_name.p12"
    
    # Clean up
    rm "/tmp/$client_name-cert.json"
    
    echo "✅ Certificate deployed for $client_name"
}

# Deploy CA certificate
echo "🔐 Deploying CA certificate..."
vault kv get -field=certificate secret/cloudya/certificates/ca | base64 -d > "$CERT_DIR/ca/ca.crt"
chmod 644 "$CERT_DIR/ca/ca.crt"

# Deploy client certificates
deploy_cert_from_vault "github-runner" "$CERT_DIR/clients/github-runner"
deploy_cert_from_vault "admin" "$CERT_DIR/clients/admin"

echo "✅ All certificates deployed successfully"
EOF

    sudo mv "/tmp/deploy-certificates.sh" "/opt/cloudya/scripts/deploy-certificates.sh"
    sudo chmod +x "/opt/cloudya/scripts/deploy-certificates.sh"
    
    log "✅ Certificate deployment script created"
}

# Main execution
main() {
    log "🚀 Starting CloudYa client certificate setup..."
    
    # Check if running as root
    if [[ $EUID -ne 0 ]]; then
        echo -e "${RED}❌ This script must be run as root${NC}"
        exit 1
    fi
    
    # Create directory structure
    create_directories
    
    # Create CA certificate
    create_ca_certificate
    
    # Create client certificates
    create_client_certificate "github-runner" "GitHub Actions Runner" 365
    create_client_certificate "admin" "Administrative Access" 365
    
    # Update Traefik configuration
    update_traefik_config
    
    # Create deployment script
    mkdir -p /opt/cloudya/scripts
    create_deployment_script
    
    log "🎉 Client certificate setup complete!"
    
    echo ""
    echo -e "${GREEN}📋 CERTIFICATE SUMMARY${NC}"
    echo -e "${YELLOW}================================${NC}"
    echo -e "CA Certificate:     ${BLUE}$CA_DIR/ca.crt${NC}"
    echo -e "GitHub Runner Cert: ${BLUE}$CLIENT_DIR/github-runner/github-runner.crt${NC}"
    echo -e "Admin Client Cert:  ${BLUE}$CLIENT_DIR/admin/admin.crt${NC}"
    echo -e "${YELLOW}================================${NC}"
    
    echo ""
    echo -e "${BLUE}📝 NEXT STEPS:${NC}"
    echo "1. Update Docker Compose to mount certificates"
    echo "2. Configure Traefik to use client certificate authentication"
    echo "3. Install client certificates on authorized devices"
    echo "4. Test client certificate authentication"
    echo "5. Enable client certificate requirement for sensitive services"
    
    echo ""
    echo -e "${YELLOW}⚠️  SECURITY NOTES:${NC}"
    echo "• Store client certificates securely"
    echo "• Distribute PKCS#12 files via secure channels only"
    echo "• Monitor certificate expiration dates"
    echo "• Revoke compromised certificates immediately"
    echo "• Rotate certificates annually"
}

# Execute main function
main "$@"